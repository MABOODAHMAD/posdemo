<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if(!function_exists('sessionUserData'))
{
    function sessionUserData(){
        $CI =get_instance();
        $CI->load->library('session');
        $sessionData = $CI->session->userdata();
        $CI->load->model('universal_model');
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM USERS WHERE ID='{$sessionData['userId']}'","row");
        return $data;
    }
}

if(!function_exists('dateTime'))
{
    function dateTime(){
        $timeZone = date_default_timezone_set("Asia/Kolkata");
        return date('Y-m-d H:i:s');
    }
}

if(!function_exists('systemVat'))
{
    function systemVat(){
        $vat = 15;
        return $vat;
    }
}

if(!function_exists('delete_cache'))
{
    function delete_cache($uri_string=null){
        $CI =& get_instance();
        $path = $CI->config->item('cache_path');
        $path = rtrim($path, DIRECTORY_SEPARATOR);

        $cache_path = ($path == '') ? APPPATH.'cache/' : $path;

        $uri =  $CI->config->item('base_url').
                $CI->config->item('index_page').
                $uri_string;

        $cache_path .= md5($uri);

        return unlink($cache_path);
    }
}



if(!function_exists('userRoleSidePanel'))
{
    function userRoleSidePanel($type,$allow=''){
        //$allow value VIEW,ADD,UPDATE 
        //$type Value rep,pro,pur,inv,hsn,cat,sale,brnd,exp
        $CI =get_instance();
        $CI->load->library('session');
        $sessionData = $CI->session->userdata();
        $CI->load->model('universal_model');
        if($allow === 'ADD'){$allow = ",SUBSTRING_INDEX(SUBSTRING_INDEX(ar.allowed, ',',1), ',',-1) as allow";
        }elseif ($allow === 'VIEW') { $allow = ",SUBSTRING_INDEX(SUBSTRING_INDEX(ar.allowed, ',',2), ',',-1) as allow";
        }elseif ($allow === 'UPDATE') { $allow = ",SUBSTRING_INDEX(SUBSTRING_INDEX(ar.allowed, ',',3), ',',-1) as allow"; }
            $data =  $CI->universal_model->CoreQuery("SELECT *$allow FROM staff as s JOIN assign_role as ar ON ar.emp_id=s.id  WHERE s.emp_email='{$sessionData['username']}' AND ar.reqst='$type'","row");
        return $data;
    }
}

if(!function_exists('sessionCheck'))
{
    function sessionCheck($con='dash'){
        $CI =get_instance();
        $CI->load->library('session');
        $sessionData = $CI->session->userdata();
        
        if($con == 'dash'){

            if(!isset($sessionData['login'])){
                redirect(base_url(), 'refresh');
            }
        }
        if($con == 'login'){
            if(isset($sessionData['login'])){
                redirect(base_url('dashboard'), 'refresh');
            }
        }
        
    }
}

if(!function_exists('datatableSqlData'))
{
    function datatableSqlData($sqlQueryTemp)
    {
        // $data = array();

        $data['SELECT'] = $sqlQueryTemp['SELECT'];
        $data['FROM'] = $sqlQueryTemp['FROM'];
        $data['JOIN_1_CONTROL'] = isset($sqlQueryTemp['JOIN_1_CONTROL'])?$sqlQueryTemp['JOIN_1_CONTROL']:FALSE; // TABLE JOINING CONTROL TRUE ENABLE AND FALSE DISABLE
        $data['JOIN_2_CONTROL'] = isset($sqlQueryTemp['JOIN_2_CONTROL'])?$sqlQueryTemp['JOIN_2_CONTROL']:FALSE; // TABLE JOINING CONTROL TRUE ENABLE AND FALSE DISABLE
        $data['JOIN_3_CONTROL'] = isset($sqlQueryTemp['JOIN_3_CONTROL'])?$sqlQueryTemp['JOIN_3_CONTROL']:FALSE; // TABLE JOINING CONTROL TRUE ENABLE AND FALSE DISABLE
        $data['JOIN_4_CONTROL'] = isset($sqlQueryTemp['JOIN_4_CONTROL'])?$sqlQueryTemp['JOIN_4_CONTROL']:FALSE; // TABLE JOINING CONTROL TRUE ENABLE AND FALSE DISABLE
        $data['JOIN_5_CONTROL'] = isset($sqlQueryTemp['JOIN_5_CONTROL'])?$sqlQueryTemp['JOIN_5_CONTROL']:FALSE; // TABLE JOINING CONTROL TRUE ENABLE AND FALSE DISABLE
        $data['WHERE_1_CONTROL'] = isset($sqlQueryTemp['WHERE_1_CONTROL'])?$sqlQueryTemp['WHERE_1_CONTROL']:FALSE; // TABLE WHERE CONTROL TRUE ENABLE AND FALSE DISABLE
        $data['WHERE_2_CONTROL'] = isset($sqlQueryTemp['WHERE_2_CONTROL'])?$sqlQueryTemp['WHERE_2_CONTROL']:FALSE; // TABLE WHERE CONTROL TRUE ENABLE AND FALSE DISABLE
        $data['WHERE_3_CONTROL'] = isset($sqlQueryTemp['WHERE_3_CONTROL'])?$sqlQueryTemp['WHERE_3_CONTROL']:FALSE; // TABLE WHERE CONTROL TRUE ENABLE AND FALSE DISABLE
        $data['CORE_WHERE_1_CONTROL'] = isset($sqlQueryTemp['CORE_WHERE_1_CONTROL'])?$sqlQueryTemp['CORE_WHERE_1_CONTROL']:FALSE; // TABLE CORE WHERE CONTROL TRUE ENABLE AND FALSE DISABLE
        $data['CORE_WHERE_2_CONTROL'] = isset($sqlQueryTemp['CORE_WHERE_2_CONTROL'])?$sqlQueryTemp['CORE_WHERE_2_CONTROL']:FALSE; // TABLE CORE WHERE CONTROL TRUE ENABLE AND FALSE DISABLE
        $data['CORE_WHERE_3_CONTROL'] = isset($sqlQueryTemp['CORE_WHERE_3_CONTROL'])?$sqlQueryTemp['CORE_WHERE_3_CONTROL']:FALSE; // TABLE CORE WHERE CONTROL TRUE ENABLE AND FALSE DISABLE
        $data['WHERE_IN_1_CONTROL'] = isset($sqlQueryTemp['WHERE_IN_1_CONTROL'])?$sqlQueryTemp['WHERE_IN_1_CONTROL']:FALSE; // TABLE WHERE CONTROL TRUE ENABLE AND FALSE DISABLE
        $data['GROUP_1_CONTROL'] = isset($sqlQueryTemp['GROUP_1_CONTROL'])?$sqlQueryTemp['GROUP_1_CONTROL']:FALSE; // TABLE GROUP CONTROL TRUE ENABLE AND FALSE DISABLE
            
        //JOIN 1
            if($data['JOIN_1_CONTROL']){

                $data["JOIN_1_TABLE_NAME"]=$sqlQueryTemp['JOIN_1_TABLE_NAME'];
                $data["JOIN_1_TABLE_CONN"]=$sqlQueryTemp['JOIN_1_TABLE_CONN'];

            }
        //JOIN 2
            if($data['JOIN_2_CONTROL']){

                $data["JOIN_2_TABLE_NAME"]=$sqlQueryTemp['JOIN_2_TABLE_NAME'];
                $data["JOIN_2_TABLE_CONN"]=$sqlQueryTemp['JOIN_2_TABLE_CONN'];

            }
        //JOIN 3
            if($data['JOIN_3_CONTROL']){

                $data["JOIN_3_TABLE_NAME"]=$sqlQueryTemp['JOIN_3_TABLE_NAME'];
                $data["JOIN_3_TABLE_CONN"]=$sqlQueryTemp['JOIN_3_TABLE_CONN'];

            }
         //JOIN 3
            if($data['JOIN_4_CONTROL']){

                $data["JOIN_4_TABLE_NAME"]=$sqlQueryTemp['JOIN_4_TABLE_NAME'];
                $data["JOIN_4_TABLE_CONN"]=$sqlQueryTemp['JOIN_4_TABLE_CONN'];

            }
        //JOIN 5
            if($data['JOIN_5_CONTROL']){

                $data["JOIN_5_TABLE_NAME"]=$sqlQueryTemp['JOIN_5_TABLE_NAME'];
                $data["JOIN_5_TABLE_CONN"]=$sqlQueryTemp['JOIN_5_TABLE_CONN'];

            }
        //WHERE CLAUSE 1
            if($data['WHERE_1_CONTROL']){

                $data["WHERE_1_COL_NAME"]=$sqlQueryTemp['WHERE_1_COL_NAME'];
                $data["WHERE_1_DATA"]=$sqlQueryTemp['WHERE_1_DATA'];

            }
        //WHERE CLAUSE 2
            if($data['WHERE_2_CONTROL']){

                $data["WHERE_2_COL_NAME"]=$sqlQueryTemp['WHERE_2_COL_NAME'];
                $data["WHERE_2_DATA"]=$sqlQueryTemp['WHERE_2_DATA'];

            }
        //WHERE CLAUSE 3
            if($data['WHERE_3_CONTROL']){

                $data["WHERE_3_COL_NAME"]=$sqlQueryTemp['WHERE_3_COL_NAME'];
                $data["WHERE_3_DATA"]=$sqlQueryTemp['WHERE_3_DATA'];

            }
        //CORE WHERE CLAUSE 1
            if($data['CORE_WHERE_1_CONTROL']){

                $data["CORE_WHERE_1_DATA"]=$sqlQueryTemp['CORE_WHERE_1_DATA'];

            }
        //CORE WHERE CLAUSE 2
            if($data['CORE_WHERE_2_CONTROL']){

                $data["CORE_WHERE_2_DATA"]=$sqlQueryTemp['CORE_WHERE_2_DATA'];

            }
        //CORE WHERE CLAUSE 3
            if($data['CORE_WHERE_3_CONTROL']){

                $data["CORE_WHERE_3_DATA"]=$sqlQueryTemp['CORE_WHERE_3_DATA'];

            }
        //WHERE_IN CLAUSE 1
            if($data['WHERE_IN_1_CONTROL']){

                $data["WHERE_IN_1_COL_NAME"]=$sqlQueryTemp['WHERE_IN_1_COL_NAME'];
                $data["WHERE_IN_1_DATA"]=$sqlQueryTemp['WHERE_IN_1_DATA'];

            }
        //WHERE_IN CLAUSE 1
            if($data['GROUP_1_CONTROL']){

                $data["GROUP_1_DATA"]=$sqlQueryTemp['GROUP_1_DATA'];

            }

    return $data;
    }
}

if(!function_exists('insertUniqueCode'))
{
    function insertUniqueCode($colName){
        $CI =get_instance();
        $CI->load->model('universal_model');
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM TABLE_ID_CODE WHERE COL_NAME='$colName'","row");
        return $data->PREFIX.'-'.$data->COUNT;
    }
}

if(!function_exists('currencyList'))
{
    function currencyList(){
        $CI =get_instance();
        $CI->load->model('universal_model');
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM CURRENCY","result_array");
        return $data;
    }
}

if(!function_exists('busUnits'))
{
    function busUnit(){
        $CI =get_instance();
        $CI->load->model('universal_model');
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM BUS_UNIT","result_array");
        return $data;
    }
}

if(!function_exists('countryList'))
{
    function countryList(){
        $CI =get_instance();
        $CI->load->model('universal_model');
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM COUNTRIES","result_array");
        return $data;
    }
}

if(!function_exists('stateList'))
{
    function stateList(){
        $CI =get_instance();
        $CI->load->model('universal_model');
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM STATES","result_array");
        return $data;
    }
}

if(!function_exists('traitCatList'))
{
    function traitCatList(){
        $CI =get_instance();
        $CI->load->model('universal_model');
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM TRAIT_CATEGORY","result_array");
        return $data;
    }
}

if(!function_exists('uomList'))
{
    function uomList(){
        $CI =get_instance();
        $CI->load->model('universal_model');
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM UNIT_OF_MEASUREMENT","result_array");
        return $data;
    }
}

if(!function_exists('classList'))
{
    function classList(){
        $CI =get_instance();
        $CI->load->model('universal_model');
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM ITEM_CLASSES","result_array");
        return $data;
    }
}

if(!function_exists('categoryList'))
{
    function categoryList(){
        $CI =get_instance();
        $CI->load->model('universal_model');
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM ITEM_CATEGORY","result_array");
        return $data;
    }
}

if(!function_exists('vendorList'))
{
    function vendorList(){
        $CI =get_instance();
        $CI->load->model('universal_model');
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM VENDOR","result_array");
        return $data;
    }
}

if(!function_exists('fYearList'))
{
    function fYearList(){
        $CI =get_instance();
        $CI->load->model('universal_model');
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM FISCAL_YEARS","row");
        return $data;
    }
}

if(!function_exists('glPrefix'))
{
    function glPrefix(){
        $CI =get_instance();
        $CI->load->model('universal_model');
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM GL_PREFIXES","row");
        return $data;
    }
}

if(!function_exists('bankDet'))
{
    function bankDet(){
        $CI =get_instance();
        $CI->load->model('universal_model');
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM BANKS","row");
        return $data;
    }
}

if(!function_exists('bankDet'))
{
    function bankDet(){
        $CI =get_instance();
        $CI->load->model('universal_model');
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM BANKS","row");
        return $data;
    }
}
/*================================ EMPLOYEE CATEGORY ==============================*/
if(!function_exists('empCat'))
{
    function empCat(){
        $CI =get_instance();
        $CI->load->model('universal_model');
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM EMP_CATEGORY","result");
        return $data;
    }
}

/*================================ SALES AREAS ==============================*/
if(!function_exists('salesArea'))
{
    function salesArea(){
        $CI =get_instance();
        $CI->load->model('universal_model');
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM SALES_AREAS","result");
        return $data;
    }
}


if(!function_exists('poPrefixes'))
{
    function poPrefixes($prefixType=null){
        $CI =get_instance();
        $CI->load->model('universal_model');
            if($prefixType){
                $prefixType = "WHERE POP_ORDER_PFX = '$prefixType'";
            }
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM PO_PREFIXES $prefixType","result_array");
        return $data;
    }
}

if(!function_exists('itemDetails'))
{
    function itemDetails($itemCode,$type=null,$venCode=null){
        $CI =get_instance();
        $CI->load->model('universal_model');
        if($type && $venCode){
            $where = "I_CODE LIKE '%$itemCode%' AND VEN_CODE = '$venCode'";
        }else if($type){
            $where = "I_CODE LIKE '%$itemCode%'";
        }else{
            $where = "I_CODE='$itemCode'";
        }
       
        $data =  $CI->universal_model->CoreQuery("SELECT * 
                                                FROM ITEMS
                                                JOIN ITEM_CATEGORY
                                                ON ITEM_CATEGORY.ICAT_CODE= ITEMS.I_CAT_CODE
                                                JOIN ITEM_CLASSES
                                                ON ITEM_CLASSES.IC_CODE = ITEMS.I_CLASS_CODE AND ITEM_CLASSES.IC_ITEM_CAT = ITEMS.I_CAT_CODE
                                                JOIN COUNTRIES
                                                ON  COUNTRIES.CNTRY_CODE= ITEMS.I_CNTRY_CODE
                                                JOIN ITEM_TRAITS
                                                ON ITEM_TRAITS.ITM_CODE = ITEMS.I_CODE
                                                JOIN TRAIT_CATEGORY
                                                ON TRAIT_CATEGORY.TC_CODE = ITEM_TRAITS.ITM_TRAIT_CAT_CODE
                                                JOIN TRAIT_SUB_CATEGORY
                                                ON TRAIT_SUB_CATEGORY.TRAIT_SUB_CAT_CODE = ITEM_TRAITS.ITM_TRAIT_CODE  AND TRAIT_SUB_CATEGORY.TRAIT_CAT_ID = ITEM_TRAITS.ITM_TRAIT_CAT_CODE
                                                JOIN VENDOR
                                                ON VENDOR.V_CODE = ITEMS.VEN_CODE
                                                JOIN UNIT_OF_MEASUREMENT
                                                ON UNIT_OF_MEASUREMENT.UOM_CODE = ITEMS.I_UOM_CODE
                                                WHERE $where
                                                ORDER BY ITEM_TRAITS.ITM_TRAIT_CODE ASC","result_array");
        return $data;
    }
}

if(!function_exists('wherehouseDetail'))
{
    function wherehouseDetail($data = array()){
        $CI =get_instance();
        $where = isset($data['where'])?$data['where']:null;
        $CI->load->model('universal_model');
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM WHAREHOUSE $where","{$data['dataType']}");
        return $data;
    }
}

if(!function_exists('busUnitDetail'))
{
    function busUnitDetail(){
        $CI =get_instance();
        $CI->load->model('universal_model');
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM BUS_UNIT
                                                        JOIN COUNTRIES
                                                        ON COUNTRIES.CNTRY_CODE= BUS_UNIT.BU_COUNTRY
                                                        JOIN STATES
                                                        ON STATES.ST_CODE = BUS_UNIT.BU_STATE
                                                        JOIN CITIES
                                                        ON CITIES.CTY_CODE = BUS_UNIT. BU_CITY","row");
        return $data;
    }
}

if(!function_exists('itemStockDet'))
{
    function itemStockDet($data = array()){
        $CI =get_instance();
        $CI->load->model('universal_model');
        // SUM(WHSE_STK_QTY) AS STOCK_QTY 
            $data =  $CI->universal_model->CoreQuery("SELECT *
                                                        FROM WHAREHOUSE_STOCK 
                                                        WHERE WHSE_STK_WHSE_ID = '{$data['whseId']}' 
                                                        AND WHSE_STK_ITEM_CODE = '{$data['itemCode']}' 
                                                        AND WHSE_STK_STATUS = 'RECEIVED'","result");
        $credit_in = $debit_in = 0;
        foreach ($data as $dataFetch) {
            if($dataFetch->WHSE_STK_TRANS_TYPE == 'CREDIT'){
                $credit_in += $dataFetch->WHSE_STK_QTY;
            }elseif ($dataFetch->WHSE_STK_TRANS_TYPE == 'DEBIT') {
                $debit_in += $dataFetch->WHSE_STK_QTY;
            }
        }

        $data = $credit_in - $debit_in;
        return $data;
    }
}

if(!function_exists('transReason'))
{
    function transReason($data = array()){
        $CI =get_instance();
        $CI->load->model('universal_model');
            $where = isset($data['where'])?$data['where']:null;
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM TRANSFER_REASON $where","{$data['dataType']}");
        return $data;
    }
}

if(!function_exists('itemUnitCost'))
{
    function itemUnitCost($data = array()){
        $CI =get_instance();
        $CI->load->model('universal_model');
            $where = isset($data['where'])?$data['where']:null;
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM ITEM_COST $where","{$data['dataType']}");
        return $data;
    }
}

if(!function_exists('transRule'))
{
    function transRule($data = array()){
        $CI =get_instance();
        $CI->load->model('universal_model');
            $where = isset($data['where'])?$data['where']:null;
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM TRANSFER_RULE $where","{$data['dataType']}");
        return $data;
    }
}

if(!function_exists('priceChnagerDetail'))
{
    function priceChnagerDetail($data = array()){
        $CI =get_instance();
        $CI->load->model('universal_model');
            $where = isset($data['where'])?$data['where']:null;
            $data =  $CI->universal_model->CoreQuery("SELECT * 
                                                        FROM PRICE_CHANGER_DETAIL
                                                        JOIN ITEMS
                                                        ON ITEMS.I_CODE = PRICE_CHANGER_DETAIL.PCD_ITEM_CODE
                                                         $where","{$data['dataType']}");
        return $data;
    }
}

if(!function_exists('StockTransferOrderDet'))
{
    function StockTransferOrderDet($data = array()){
        $CI =get_instance();
        $CI->load->model('universal_model');
            $where = isset($data['where'])?$data['where']:null;
            $data =  $CI->universal_model->CoreQuery("SELECT * 
                                                        FROM STOCK_TRANSFER_HEADER 
                                                        JOIN STOCK_TRANSFER_DETAIL
                                                        ON STOCK_TRANSFER_DETAIL.STD_ORDER_NO = STOCK_TRANSFER_HEADER.STH_ORDER_NO
                                                        JOIN TRANSFER_REASON
                                                        ON TRANSFER_REASON.TR_TRANS_RSN = STOCK_TRANSFER_HEADER.STH_TRANS_RSN
                                                        JOIN TRANSFER_RULE
                                                        ON TRANSFER_RULE.TRULE_TRANS_RULE = STOCK_TRANSFER_DETAIL.STD_TRANS_RULE
                                                        JOIN ITEMS
                                                        ON ITEMS.I_CODE = STOCK_TRANSFER_DETAIL.STD_ITEM_CODE
                                                        JOIN ITEM_CATEGORY
                                                        ON ITEM_CATEGORY.ICAT_CODE= ITEMS.I_CAT_CODE
                                                        JOIN ITEM_CLASSES
                                                        ON ITEM_CLASSES.IC_CODE = ITEMS.I_CLASS_CODE AND ITEM_CLASSES.IC_ITEM_CAT = ITEMS.I_CAT_CODE
                                                        JOIN COUNTRIES
                                                        ON  COUNTRIES.CNTRY_CODE= ITEMS.I_CNTRY_CODE
                                                        JOIN VENDOR
                                                        ON VENDOR.V_CODE = ITEMS.VEN_CODE
                                                        JOIN UNIT_OF_MEASUREMENT
                                                        ON UNIT_OF_MEASUREMENT.UOM_CODE = ITEMS.I_UOM_CODE
                                                        $where","{$data['dataType']}");
        return $data;
    }
}

// CUSTOMER TYPE
if(!function_exists('custTypeDet'))
{
    function custTypeDet($data = array()){
        $CI =get_instance();
        $CI->load->model('universal_model');
            $where = isset($data['where'])?$data['where']:null;
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM CUST_TYPE $where","{$data['dataType']}");
        return $data;
    }
}

/*================================ DEFAULT CURRENCY ==============================*/
if(!function_exists('sysCur'))
{
    function sysCur(){
        return 'SAR';
    }
}

/*================================ SWEET ALERT FORM MSG ==============================*/


if(!function_exists('sweetAlertMsg'))
{
    function sweetAlertMsg(){
        $alertData = [
            "empAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST","cont"=>"Y"],  //* EMPLOYEE ADD
            "busAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST","cont"=>"Y"], //* BUSINESS UNIT ADD
            "whseAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST","cont"=>"Y"], //* WAREHOUSE ADD
            "contyAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST","cont"=>"Y"], //* COUNTRY ADD
            "stateAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST","cont"=>"Y"], //* STATE ADD
            "cityAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST","cont"=>"Y"], //* CITY ADD
            "pssGex" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST","cont"=>"Y"], //* PASSWORD GENERATE
            "currAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST","cont"=>"Y"], //* CURRENCY ADD
            "currExchAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST","cont"=>"Y"], //* CURRENCY EXCHANGE ADD
            "UOMAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST","cont"=>"Y"], //* UOM ADD
            "itemCatAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST","cont"=>"Y"], //* ITEM CATEGORY ADD
            "itemClassAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST","cont"=>"Y"], //* ITEM CLASS ADD
            "traitCatAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST","cont"=>"Y"], //* TRAIT CATEGORY ADD
            "traitAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST","cont"=>"Y"], //* TRAIT ADD
            "payMethAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST","cont"=>"Y"], //* PAYMENT METHOD ADD
            "bankUpdate" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./UPDATE/Don't UPDATE","cont"=>"Y"], //* BANK DETAIL UPDATE
            "frightAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST","cont"=>"Y"], //* FREIGHT ADD
            "fobAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST","cont"=>"Y"], //* FOB ADD
            "shipAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST","cont"=>"Y"], //* SHIP ADD
            "termAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST","cont"=>"Y"], //* TERMS ADD
            "POchrgAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST","cont"=>"Y"], //* PO CHARGE ADD
            "POPrefixAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST","cont"=>"Y"], //* PO PREFIX ADD
            "finacYearAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST","cont"=>"Y"], //* FINANCIAL YEAR ADD
            "finacPeriAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST","cont"=>"Y"], //* FINANCIAL PERIOD ADD
            "GLPrifAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./UPDATE/Don't UPDATE","cont"=>"Y"], //* GENERAL LEDGER PREFIX ADD
            "saleAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST/SALE INVOICE CREATED/SALE NOT CREATED","cont"=>"Y"], //* SALE ADD
            "purchaseAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST/PURCHASE INVOICE CREATED/PURCHASE NOT CREATED","cont"=>"Y"], //* PURCHASE ADD
            "custAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST/CUSTOMER SUCCESSFULLY CREATED/DATA NOT POSTED","cont"=>"Y"], //* CUSTOMER ADD
            "venAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST/VENDOR SUCCESSFULLY CREATED/DATA NOT POSTED","cont"=>"Y"], //* VENDOR ADD
            "prodAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST/PRODUCT SUCCESSFULLY CREATED/DATA NOT POSTED","cont"=>"Y"], //* PRODUCT ADD
            "transAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST/TRANSFER SUCCESSFULLY CREATED/DATA NOT POSTED","cont"=>"Y"], //* TRANSFER ORDER ADD
            "purRev" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST/PURCHASE INVOICE SUCCESSFULLY RECEIVED/PURCHASE INVOICE RECEIVED AGAIN","cont"=>"Y"], //* PURCHASE RECEIVED
            "purLandedCostAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST/LANDED COST SUCCESSFULLY UPDATED/LANDED COST NOT UPDATED","cont"=>"Y"], //* LANDED COST ADD
            "payOutAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST/PAYMENT SUCCESSFULLY UPDATED/PAYMENT NOT UPDATED","cont"=>"Y"], //* PAYMENT OUT ADD
            "payInAdd" => (object)["msg"=>"Are you sure? Your data sent to the server could not be rolled back after you submitted this form./POST/Don't POST/PAYMENT SUCCESSFULLY UPDATED/PAYMENT NOT UPDATED","cont"=>"Y"], //* PAYMENT IN ADD
            
        ];

        return (object)$alertData;
    }
}

// SELECT *,SUBSTRING_INDEX(SUBSTRING_INDEX(ar.allowed, ',',4), ',',-1) as allow FROM staff as s JOIN assign_role as ar ON ar.emp_id=s.id WHERE s.emp_email='usmanahmad.czars+18@gmail.com' AND reqst='sale'
?>