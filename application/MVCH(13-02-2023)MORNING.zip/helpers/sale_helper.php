<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if(!function_exists('customerDet'))
{
    function customerDet($data = array()){
        $CI =get_instance();
        $CI->load->library('session');
        $sessionData = $CI->session->userdata();
        $CI->load->model('universal_model');
            $where = isset($data['where'])?$data['where']:null;
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM CUSTOMER $where","{$data['dataType']}");
        return $data;
    }
}
/**========================================================================
 *                           SALE ORDER DETAIL
 *========================================================================**/
if(!function_exists('saleOrderDet'))
{
    function saleOrderHeadDet($data = array()){
        $CI =get_instance();
        $CI->load->library('session');
        $sessionData = $CI->session->userdata();
        $CI->load->model('universal_model');
            $where = isset($data['where'])?$data['where']:null;
            $data =  $CI->universal_model->CoreQuery("SELECT *,ROUND(SH_GRAND_TOT) SH_GRAND_TOT FROM SALE_HEADER SH,CUSTOMER C,CITIES CT,STATES ST,COUNTRIES CONT,EMPLOYEE E
                                                    WHERE SH.SH_CUST_ID = C.CUST_CODE
                                                    AND C.CUST_CITY_ID = CT.CTY_CODE
                                                    AND C.CUST_STATE_ID = ST.ST_CODE
                                                    AND C.CUST_COUNTRY_ID = CONT.CNTRY_CODE
                                                    AND E.EMP_CODE = SH.SH_SALESMAN_ID
                                                    $where","{$data['dataType']}");
        return $data;
    }
}
/**========================================================================
 *                           SALE ORDER DETAILE LINE
 *========================================================================**/
if(!function_exists('saleOrderLineDet'))
{
    function saleOrderLineDet($data = array()){
        $CI =get_instance();
        $CI->load->library('session');
        $sessionData = $CI->session->userdata();
        $CI->load->model('universal_model');
            $where = isset($data['where'])?$data['where']:null;
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM SALE_DETAIL SD,ITEMS I
                                                    WHERE SD.SD_ITEM_CODE = I.I_CODE
                                                    $where","{$data['dataType']}");
        return $data;
    }
}
/**========================================================================
 *                           GET PAYMENT DETAIL BY ORDER ID
 *========================================================================**/
if(!function_exists('paymentDetails'))
{
    function paymentDetails($data = array()){
        $CI =get_instance();
        $CI->load->library('session');
        $sessionData = $CI->session->userdata();
        $CI->load->model('universal_model');
            $where = isset($data['where'])?$data['where']:null;
            $data =  $CI->universal_model->CoreQuery("SELECT * FROM PAYMENT_DETAIL PD,PAY_METHODS PM
                                                    WHERE PD.PD_PAY_METHOD_ID = PM.PM_CODE
                                                    $where","{$data['dataType']}");
        return $data;
    }
}

/**========================================================================
 *                           CUSTOMER TOT AMT OTHER DETAIL
 *========================================================================**/

 if(!function_exists('custBalDetail'))
 {
     function custBalDetail($data = array()){
 
         $CI =get_instance();
         $CI->load->model('universal_model');
         $data =  $CI->universal_model->CoreQuery("SELECT SUM(SH_GRAND_TOT-SH_PAID_AMT) AS OUTSTANDING_AMT FROM SALE_HEADER WHERE SH_CUST_ID='{$data['custCode']}'","{$data['dataType']}");
         return $data;
 
     }
 }

 /**========================================================================
 *                           ALL INVOICE BY CUSTOMER CODE
 *========================================================================**/
if(!function_exists('invDetByCustCode'))
{
    function invDetByCustCode($data = array()){

        $CI =get_instance();
        $CI->load->model('universal_model');
        $where = isset($data['where'])?$data['where']:null;
        $data =  $CI->universal_model->CoreQuery("SELECT * FROM SALE_HEADER 
                                                    $where","{$data['dataType']}");
        return $data;

    }
}

/**========================================================================
 *                           SYNC PAYMENT STATUS
 *========================================================================**/

 if(!function_exists('syncPayStatusForCust'))
{
    function syncPayStatusForCust($data = array()){

        $CI =get_instance();
        $CI->load->model('universal_model');
            $IncDetByVens = $data;
            foreach ($IncDetByVens as $IncDetByVen) {
               if ($IncDetByVen->SH_GRAND_TOT == $IncDetByVen->SH_PAID_AMT) {
                    $status = 'PAID';
                    $incSta = 'CLOSE';
               }elseif ($IncDetByVen->SH_GRAND_TOT > $IncDetByVen->SH_PAID_AMT && $IncDetByVen->SH_PAID_AMT>0) {
                    $status = 'PARTIAL';
                    $incSta = 'OPEN';
               }else{
                    $status = 'PENDING';
                    $incSta = 'OPEN';
               }
                $CI->universal_model->CoreQuery("UPDATE SALE_HEADER SET SH_PAY_STATUS = '$status',SH_STATUS='$incSta'  WHERE SH_ORDER_ID = '{$IncDetByVen->SH_ORDER_ID}'");

            }
        return true;

    }
}

/**========================================================================
 *                           SALE ORDER LINE DETAIL
 *========================================================================**/
if(!function_exists('saleOrderLineDetail'))
{
    function saleOrderLineDetail($data = array()){

        $CI =get_instance();
        $CI->load->model('universal_model');
            $IncDetByVens = $data;
            foreach ($IncDetByVens as $IncDetByVen) {
               if ($IncDetByVen->SH_GRAND_TOT == $IncDetByVen->SH_PAID_AMT) {
                    $status = 'PAID';
                    $incSta = 'CLOSE';
               }elseif ($IncDetByVen->SH_GRAND_TOT > $IncDetByVen->SH_PAID_AMT && $IncDetByVen->SH_PAID_AMT>0) {
                    $status = 'PARTIAL';
                    $incSta = 'OPEN';
               }else{
                    $status = 'PENDING';
                    $incSta = 'OPEN';
               }
                $CI->universal_model->CoreQuery("UPDATE SALE_HEADER SET SH_PAY_STATUS = '$status',SH_STATUS='$incSta'  WHERE SH_ORDER_ID = '{$IncDetByVen->SH_ORDER_ID}'");

            }
        return true;

    }
}