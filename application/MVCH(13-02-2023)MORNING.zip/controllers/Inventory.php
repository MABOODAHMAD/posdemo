<?php
     class Inventory extends CI_Controller{
         public function __construct(){
            parent::__construct();
            $this->load->model('Universal_model','unicon');
         }

         
        public function stockTransTransotUpdate(){
            $userCon = sessionUserData();
            header('Content-Type: application/json');
            $transResn = $this->input->post('trns_resn');
            $orderNo = $this->input->post('order_no_db');

            $stockTransferOrderDets = StockTransferOrderDet(["where" => "WHERE STH_ORDER_NO = '$orderNo'", "dataType" => 'result']);
            $stockChk = false;
            foreach ($stockTransferOrderDets as $stockTransferOrderDet) {
                $item_P = array(
                    "dataType" => 'row',
                    "itemCode" => $stockTransferOrderDet->STD_ITEM_CODE,
                    "whseId" => $stockTransferOrderDet->STH_FROM_WHSE,
                );
                $stockDet = itemStockDet($item_P);
                if($stockDet >= $stockTransferOrderDet->STD_TRANS_QTY){
                    $stockChk = true;
                }else{
                    $stockChk = false;
                    break;
                }
            }
        // if ($stockChk) {
            if ($transResn == 200) {
                $data = [
                    "STH_STATUS" => "RECEIVED"
                ];
                $updateWhere = "STH_ORDER_NO = '$orderNo'";
                $stockChk = true;
            } elseif ($transResn == 201 && $stockChk) {
                $trnsStatus = $this->input->post('trns_status');
                $trnsStausIn = $trnsStatus == 'ORDER' ? 'IN-TRANSIT' : 'RECEIVED';
                $data = [
                    "STH_STATUS" => $trnsStausIn
                ];
                $updateWhere = "STH_ORDER_NO = '$orderNo'";
                $stockChk = true;
            } elseif ($transResn == 202 && $stockChk) {
                $data = [
                    "STH_STATUS" => "RECEIVED"
                ];
                $updateWhere = "STH_ORDER_NO = '$orderNo'";
                $stockChk = true;
            } elseif ($transResn == 204) {
                $data = [
                    "STH_STATUS" => "RECEIVED"
                ];
                $updateWhere = "STH_ORDER_NO = '$orderNo'";
                $stockChk = true;
            }else{
                $stockChk = false;
            }
            $check = $stockChk?$this->unicon->updateArrayUniversal('STOCK_TRANSFER_HEADER',$data,$updateWhere):false;
        // }else{
        //     $check = false;
        // }
            // $check = $this->unicon->updateArrayUniversal('STOCK_TRANSFER_HEADER',$data,$updateWhere);
            
            // NOTE :  WHAREHOUSE STOCK STATUS UPDATE AFTER TRANSFER HEADER UPDATE *** THROUGH TRIGGER : UPDATE_WHAREHOUSE_STOCK_STATUS
                // $check = false;
                if($check){    
                    echo json_encode(array("multi" => "false", "err" => "false", "msg" => "$transResn"));
                }elseif(!$stockChk){
                    echo json_encode(array("multi" => "false", "err" => "false", "msg" =>"stock_empty"));
                }else{
                    echo json_encode(array("multi" => "false", "err" => "true", "msg" => "Please add some item"));
                    }
            }
            
        public function stockTransOrderAdd(){
            $userCon = sessionUserData();
            header('Content-Type: application/json');

            $this->form_validation->set_rules('order_no_db', 'stock order no', 'required|unique_code_db[PRICE_CHANGER_HEADER.PCH_DOCUMENT_NO.Document No already used, Please reFresh this page]');
            $this->form_validation->set_rules('trans_resn_db', 'transfer reason', 'required');
            // $this->form_validation->set_rules('trans_rule_db', 'transfer rule', 'required');
            $this->form_validation->set_rules('from_whse_db', 'from wharehouse', 'required');
            $this->form_validation->set_rules('to_whse_db', 'to wharehouse', 'required');
            
            if ($this->form_validation->run() === FALSE) {
                $omsg = $this->form_validation->error_array();
                echo json_encode(array("multi" => "true", "err" => "true", "msg" => $omsg));
            } else {
                $orderNo = $this->input->post('order_no_db');
                $itemCode = $this->input->post('STD_ITEM_CODE');
                $listPrice = $this->input->post('STD_UNIT_LIST_PRICE');
                $qty = $this->input->post('STD_TRANS_QTY');
                $stockTransRule = $this->input->post('STD_TRANS_RULE');
                $check = false;
                
                // refrence_db
                $headerData = [
                    "STH_ORDER_NO" => $orderNo,
                    "STH_YEAR" => date('Y'),
                    "STH_PERIOD" => date('m'),
                    "STH_TRANS_DATE" => date('Y-m-d'),
                    "STH_TRANS_RSN" => $this->input->post('trans_resn_db'),
                    "STH_FROM_WHSE" => $this->input->post('from_whse_db'),
                    "STH_WHSE_TO" => $this->input->post('to_whse_db'),
                    "STH_STATUS" => "ORDER",
                    "STH_CRE_BY" => $userCon->ID,
                ];

                $headerIn = true;
                for ($i=0; $i < count($itemCode) ; $i++) { 
                    if($itemCode[$i] && $listPrice[$i]>0 && $qty[$i]>0){
                       
                        $headerIn?$this->unicon->insertUniversal('STOCK_TRANSFER_HEADER',$headerData):null;
                        $unitCost = itemUnitCost(['where' => "WHERE INVCOST_ITEM_CODE = '{$itemCode[$i]}' ORDER BY INVCOST_ID DESC LIMIT 1",'dataType'=>"row"]);
                    
                        $detailData = [
                            "STD_ORDER_NO" => $orderNo ,
                            "STD_ITEM_CODE" => $itemCode[$i],
                            "STD_UNIT_LIST_PRICE" => $listPrice[$i],
                            "STD_TRANS_QTY" => $qty[$i],
                            "STD_TRANS_RULE" => $stockTransRule[$i],
                            "STD_UNIT_COST" => $unitCost->INVCOST_ACT_COST,
                            "STD_CRE_BY" =>$userCon->ID,
                        ];
                      
                        $this->unicon->insertUniversal('STOCK_TRANSFER_DETAIL',$detailData);
                        // NOTE STOCK TRANSFER DETAIL INSERT WHAREHOUSE STOCK *** TRIGGER NAME : TRANSFER_ORDER_DETAILS_ADD_WHSE_STOCK ***
                        
                        $check = true;
                        $headerIn = false;
                    }
                }
                
                if($check){
                    $url = "<script>location.reload();</script>";
                    echo json_encode(array("multi" => "false", "err" => "false", "msg" => "Stock transfer order create Successfully".$url));
                }else{
                    echo json_encode(array("multi" => "false", "err" => "true", "msg" => "Please add some item"));
                    }
                }
            }

            public function inventoryListJson(){
                $whseCOde = $this->input->post('whse_code');

                $filterdata = array(
                    "column_order" => array(NULL,'I_CODE','I_DESC','VEN_CODE','I_CNTRY_CODE','I_CAT_CODE',NULL),
                    "column_search" => array('I_CODE','I_DESC','VEN_CODE','I_CNTRY_CODE','I_CAT_CODE'),
                    "order" => array('I_CRE_DATE' => 'DESC')
                );
    
                $sqlQueryTemp = array(
    
                    "SELECT"=>'*',
                    "FROM"=>'ITEMS',
    
                    "JOIN_1_CONTROL"=>FALSE,  // TABLE JOINING CONTROL TRUE ENABLE AND FALSE DISABLE DEFAULT VALUE FALSE
                        "JOIN_1_TABLE_NAME"=>'TRAIT_CATEGORY',
                        "JOIN_1_TABLE_CONN"=>'TRAIT_CATEGORY.TC_CODE=ITEM_TRAITS.ITM_TRAIT_CAT_CODE',
    
                    "JOIN_2_CONTROL"=>FALSE,  // TABLE JOINING CONTROL TRUE ENABLE AND FALSE DISABLE DEFAULT VALUE FALSE
                        "JOIN_2_TABLE_NAME"=>'TRAIT_SUB_CATEGORY',
                        "JOIN_2_TABLE_CONN"=>'TRAIT_SUB_CATEGORY.TRAIT_CAT_ID=ITEM_TRAITS.ITM_TRAIT_CAT_CODE AND TRAIT_SUB_CATEGORY.TRAIT_SUB_CAT_CODE=ITEM_TRAITS.ITM_TRAIT_CODE',
                    
                    "WHERE_1_CONTROL"=>FALSE,  // TABLE WHERE CLOUSE CONTROL TRUE ENABLE AND FALSE DISABLE DEFAULT VALUE FALSE
                        "WHERE_1_COL_NAME"=>'ITEM_TRAITS.ITM_CODE',
                        "WHERE_1_DATA"=>'',
                );
                
  
                
                
                $sqlQuery = datatableSqlData($sqlQueryTemp);
    
                $memData = $this->datatableCon->getRows($_POST,$sqlQuery,$filterdata);
    
                $data = array();
                $no = $this->input->post('start');
                foreach ($memData as $rowdata) {
                    
                    $itemCodeEncrpt = dataEncypt($rowdata->I_CODE,'encrypt');
                    $itemCodeBak = dataEncyptManual($rowdata->I_CODE, 'encrypt');
                    
                        $avlQty = 0;
                        $noOfWhareHoses = wherehouseDetail(['dataType' => 'result']);
                        foreach ($noOfWhareHoses as $noOfWhareHose) {
                            if (isset($whseCOde)) {
                                if ($whseCOde == $noOfWhareHose->WHSE_CODE || $whseCOde == 'ALL') {

                                    $item_P = array(
                                        "dataType" => 'row',
                                        "itemCode" => $rowdata->I_CODE,
                                        "whseId" => $noOfWhareHose->WHSE_CODE,
                                    );
                                    $avlQty += itemStockDet($item_P);
                                }
                            }else{
                                $item_P = array(
                                    "dataType" => 'row',
                                    "itemCode" => $rowdata->I_CODE,
                                    "whseId" => $noOfWhareHose->WHSE_CODE,
                                );
                                $avlQty += itemStockDet($item_P);
                            }
                        }
                    
                    if ($avlQty>0) {
                    $no++; $row = array();
                    $row[] = $no.".";
                    $row[] = "<img src='http://moallim.e-invoicesaudi.com/uploads/images/item/$rowdata->I_IMAGE_FILENAME' class='avatar-sm'>
                    <h5 class='text-truncate font-size-14'><a href='".base_url('ProductDetail?item_code=').$itemCodeEncrpt.'&item_code_bak='.$itemCodeBak."' class='text-dark'>$rowdata->I_CODE</a></h5>";
                    $row[] = $rowdata->I_DESC;
                    $row[] = "<span class='badge bg-success'>$avlQty</span>";
                    $row[] = $rowdata->VEN_CODE;
                    $row[] = $rowdata->I_SECONDARY_DESC;
                    $row[] = $rowdata->I_CAT_CODE;
                    $row[] = "<button  data-itemcode='{$rowdata->I_CODE}' class='btn btn-primary btn-sm btn-rounded' data-bs-toggle='modal' data-bs-target='#standard_model' onClick='viewUnitDet(this)'>View Uniit Cost</button>";
                   // $row[] = "<a href='".base_url('addItemTrait?item_code=').$itemCodeEncrpt.'&type=view'."'> <button type='button' class='btn btn-primary btn-sm btn-rounded'>View Details</button></a>";
                //   $row[] = "<ul class='list-unstyled hstack gap-1 mb-0'>
                //                 <li data-bs-toggle='tooltip' data-bs-placement='top' title='Edit'>
                //                     <a href='#' class='btn btn-sm btn-soft-info'><i class='mdi mdi-pencil-outline'></i></a>
                //                 </li>
                //             </ul>";
                        // if ($avlQty>0) {
                            $data[] = $row;
                        }
                    
                }
                $data = array_values_recursive($data);
                $output = array(
                    "draw" => empty($this->input->post('draw')) ? 'none' : $this->input->post('draw'),
                    "recordsTotal" => $this->datatableCon->countAll($sqlQuery),
                    "recordsFiltered" => $this->datatableCon->countFiltered($_POST,$sqlQuery),
                    "data" => $data
                );
                //output to json format
                header('Content-Type: application/json');
                echo json_encode($output);
            }


            public function stockTransOrderListJson(){
                // $itemCode = $this->input->post('item_code');

                $filterdata = array(
                    "column_order" => array(NULL,'STH_ORDER_NO','STH_TRANS_DATE','TR_DESC','STH_FROM_WHSE','STH_WHSE_TO','STH_TOT_QTY','STH_GRAND_TOT','STH_STATUS',NULL),
                    "column_search" => array('TR_DESC','STH_TRANS_DATE','STH_ORDER_NO','STH_FROM_WHSE','STH_WHSE_TO','STH_TOT_QTY','STH_GRAND_TOT','STH_STATUS'),
                    "order" => array('STH_CRE_DATE' => 'DESC')
                );

                // <th>Invoice Date</th>
                // <th>Invoice No</th>
                // <th>Warehouses/ Store (From)</th>
                // <th>Warehouses/ Store (To)</th>
                // <th>Amount</th>
                // <th>Qty</th>
                // <th>Status</th>
    
                $sqlQueryTemp = array(
    
                    "SELECT"=>'*',
                    "FROM"=>'STOCK_TRANSFER_HEADER',
    
                    "JOIN_1_CONTROL"=>TRUE,  // TABLE JOINING CONTROL TRUE ENABLE AND FALSE DISABLE DEFAULT VALUE FALSE
                        "JOIN_1_TABLE_NAME"=>'TRANSFER_REASON',
                        "JOIN_1_TABLE_CONN"=>'TRANSFER_REASON.TR_TRANS_RSN=STOCK_TRANSFER_HEADER.STH_TRANS_RSN',
    
                    "JOIN_2_CONTROL"=>FALSE,  // TABLE JOINING CONTROL TRUE ENABLE AND FALSE DISABLE DEFAULT VALUE FALSE
                        "JOIN_2_TABLE_NAME"=>'TRAIT_SUB_CATEGORY',
                        "JOIN_2_TABLE_CONN"=>'TRAIT_SUB_CATEGORY.TRAIT_CAT_ID=ITEM_TRAITS.ITM_TRAIT_CAT_CODE AND TRAIT_SUB_CATEGORY.TRAIT_SUB_CAT_CODE=ITEM_TRAITS.ITM_TRAIT_CODE',
                    
                    "WHERE_1_CONTROL"=>FALSE,  // TABLE WHERE CLOUSE CONTROL TRUE ENABLE AND FALSE DISABLE DEFAULT VALUE FALSE
                        "WHERE_1_COL_NAME"=>'ITEM_TRAITS.ITM_CODE',
                        "WHERE_1_DATA"=>'',
                );
                
  
                
                
                $sqlQuery = datatableSqlData($sqlQueryTemp);
    
                $memData = $this->datatableCon->getRows($_POST,$sqlQuery,$filterdata);
    
                $data = array();
                $no = $this->input->post('start');
                foreach ($memData as $rowdata) {
                    $no++; $row = array();
                    $orderId = dataEncyptbase64($rowdata->STH_ORDER_NO,'encrypt');
                    $row[] = $no.".";
           
                    $row[] = "<a href='".base_url('StockTransferView?orderid=').$orderId."' class='text-body fw-bold'>{$rowdata->STH_ORDER_NO}</a>";
                    $row[] = date('d-M Y', strtotime($rowdata->STH_TRANS_DATE));
                    $row[] = $rowdata->TR_DESC;
                    $row[] = $rowdata->STH_FROM_WHSE;
                    $row[] = $rowdata->STH_WHSE_TO;
                    $row[] = $rowdata->STH_TOT_QTY;
                    $row[] = $rowdata->STH_GRAND_TOT;
                    $row[] = $rowdata->STH_STATUS;
                  
                   // $row[] = "<a href='".base_url('addItemTrait?item_code=').$itemCodeEncrpt.'&type=view'."'> <button type='button' class='btn btn-primary btn-sm btn-rounded'>View Details</button></a>";
                  $row[] = "<ul class='list-unstyled hstack gap-1 mb-0'>
                                <li data-bs-toggle='tooltip' data-bs-placement='top' title='Edit'>
                                    <a href='#' class='btn btn-sm btn-soft-info'><i class='mdi mdi-pencil-outline'></i></a>
                                </li>
                            </ul>";
                    $data[] = $row;
                }
                $output = array(
                    "draw" => empty($this->input->post('draw')) ? 'none' : $this->input->post('draw'),
                    "recordsTotal" => $this->datatableCon->countAll($sqlQuery),
                    "recordsFiltered" => $this->datatableCon->countFiltered($_POST,$sqlQuery),
                    "data" => $data
                );
                //output to json format
                header('Content-Type: application/json');
                echo json_encode($output);
            }

    }