<?php
     class Common extends CI_Controller{
         public function __construct(){
            parent::__construct();
      
            // $this->load->model('Site_model', 'dbcon');
            $this->load->model('Universal_model','unicon');
            // $this->load->library('form_validation');
            // $this->load->helper('form');
            //$this->load->model('QrController','qrcon');
         }

        public function getStateByCntryCode(){
            $cntryCode = $this->input->post('country_code');
            $data = $this->unicon->CoreQuery("SELECT * FROM STATES WHERE ST_CNTRY_ID='$cntryCode'","result_array");
            echo json_encode($data);
        }

        /*================================ get salesman wharehouse details ==============================*/
        
        public function getSalesmanWhseDet(){
            $salesCode = $this->input->post('salesman_code');
            $data = $this->unicon->CoreQuery("SELECT * 
                                                FROM SALES_MAN_ASSIGN_WHSE,WHAREHOUSE
                                                WHERE SMSW_WHSE_CODE = WHSE_CODE AND
                                                SMSW_SLSP_CODE='$salesCode'","result");
            echo json_encode($data);
        }

        public function getCItyByStCode(){
            $stateCode = $this->input->post('state_code');
            $data = $this->unicon->CoreQuery("SELECT * FROM CITIES WHERE CTY_STATE_CODE='$stateCode'","result_array");
            echo json_encode($data);
        }

        public function getClassDescbyCode(){
            $classCode = $this->input->post('class_code');
            $data = $this->unicon->CoreQuery("SELECT * FROM ITEM_CLASSES WHERE IC_CODE='$classCode'","result_array");
            echo json_encode($data);
        }

        public function getCatDescbyCode(){
            $catCode = $this->input->post('cat_code');
            $data = $this->unicon->CoreQuery("SELECT * FROM ITEM_CATEGORY WHERE ICAT_CODE='$catCode'","result_array");
            echo json_encode($data);
        }

        public function getCntryDescbyCode(){
            $cntryCode = $this->input->post('cntry_code');
            $data = $this->unicon->CoreQuery("SELECT * FROM COUNTRIES WHERE CNTRY_CODE='$cntryCode'","result_array");
            echo json_encode($data);
        }

        public function getClassListByCategoryCode(){
            $catCode = $this->input->post('cat_code');
            $data = $this->unicon->CoreQuery("SELECT * FROM ITEM_CLASSES WHERE IC_ITEM_CAT='$catCode'","result_array");
            echo json_encode($data);
        }

        public function getTraitListbyCode(){
            $catCode = $this->input->post('cat_code');

            $catDesc = $this->unicon->CoreQuery("SELECT * FROM TRAIT_CATEGORY WHERE TC_CODE='$catCode'","result_array");
            $data = $this->unicon->CoreQuery("SELECT * FROM TRAIT_SUB_CATEGORY WHERE TRAIT_CAT_ID='$catCode'","result_array");

            echo json_encode(['trait_data'=>$data,'cat_desc'=>count($catDesc)==1?$catDesc[0]['TC_DESC']:'Data not Available']);
        }

        public function getItemTraitByItemCode(){
            $itemCode = $this->input->post('itemCode');

            $itemDel = $this->unicon->CoreQuery("SELECT * FROM ITEMS WHERE I_CODE='$itemCode'","result_array");

            $data = $this->unicon->CoreQuery("SELECT * FROM ITEMS as I
                                                        JOIN ITEM_TRAITS AS IT
                                                        ON IT.ITM_CODE =I.I_CODE
                                                        JOIN TRAIT_CATEGORY AS TC
                                                        ON TC.TC_CODE = IT.ITM_TRAIT_CAT_CODE
                                                        JOIN TRAIT_SUB_CATEGORY AS TSC
                                                        ON TSC.TRAIT_SUB_CAT_CODE =IT.ITM_TRAIT_CODE AND TSC.TRAIT_CAT_ID =IT.ITM_TRAIT_CAT_CODE
                                                        WHERE I.I_CODE='$itemCode'","result_array");

            echo json_encode(['traitDeaits'=>$data,'itemdel'=>count($itemDel)==1?$itemDel:NULL]);
        }

        public function getVenDelByVenCode(){
            $venCode = $this->input->post('ven_code');
            $data = $this->unicon->CoreQuery("SELECT * FROM VENDOR WHERE V_CODE LIKE '$venCode%'","row_array");
            echo json_encode(['ven_det'=>$data]);
        }

        public function getEmpDetByEmpCode(){
            $data = $data1 = array();

            $searchType = $this->input->get('searchtype');
            $venCode = $this->input->get('term');

            $venLists = $this->unicon->CoreQuery("SELECT EMP_CODE AS CODE,EMP_NAME1 AS ENG_NAME,EMP_NAME2 AS NAME_AR,EMP_STR_ADDR1 AS ADD1,EMP_PHONE1 AS PHONE1,EMP_DISC_PER AS EMP_DISC
                                                    FROM EMPLOYEE 
                                                    WHERE EMP_CODE LIKE '%$venCode%' 
                                                    OR EMP_NAME1 LIKE '%$venCode%'
                                                    OR EMP_NAME2 LIKE '%$venCode%'",$searchType == 'list'?"result":"row");
            if ($searchType == 'list') {
                foreach ($venLists as $venList) {
                    $data['id'] = $venList->CODE;
                    $data["value"] =  $venList->CODE.'-'.$venList->ENG_NAME.'-'.$venList->NAME_AR;
                    $data1[] = $data;
                 }

                $json = json_encode($data1);
                echo $this->input->get('callback')."({$json})";
            }else{
            $venBalDet = vendorBalDetail(["venCode"=>$venCode,"dataType"=>"row"]);
            // print_r($venBalDet);
                echo json_encode([
                                    "vend_det" => $venLists,
                                    "vend_outstanding_amt"=>$venBalDet->OUTSTANDING_AMT?$venBalDet->OUTSTANDING_AMT:0]);
            }
  
        }

        public function getCustDelByCustCode(){
            $custCode = $this->input->post('cust_code');
            $data = customerDet(['dataType' => 'row','where'=> "WHERE CUST_CODE LIKE '$custCode%' OR CUST_NAME LIKE '$custCode%' OR CUST_NAME_AR LIKE '$custCode%'"]);
            echo json_encode(['cust_det'=>$data]);
        }

        public function getFreightDelByfreightCode(){
            $frtCode = $this->input->post('freight_code');
            $data = $this->unicon->CoreQuery("SELECT * FROM FREIGHTS WHERE FRT_CODE LIKE '$frtCode%'","row_array");
            echo json_encode(['freight_det'=>$data]);
        }

        public function getTermdetBytermCode(){
            $termCode = $this->input->post('term_code');
            $data = $this->unicon->CoreQuery("SELECT * FROM TERMS WHERE TERM_CODE LIKE '$termCode%'","row_array");
            echo json_encode(['term_det'=>$data]);
        }

        public function getFobdetByFobCode(){
            $fobCode = $this->input->post('fob_code');
            $data = $this->unicon->CoreQuery("SELECT * FROM FOBS WHERE FOB_CODE LIKE '$fobCode%'","row_array");
            echo json_encode(['fob_det'=>$data]);
        }

        public function getShipDetByShipCode(){
            $shipCode = $this->input->post('ship_code');
            $data = $this->unicon->CoreQuery("SELECT * FROM SHIP_VIA WHERE SHIPV_CODE LIKE '$shipCode%'","row_array");
            echo json_encode(['ship_det'=>$data]);
        }

        public function getPOChargeByPoCode(){
            $poChargeType = $this->input->post('po_charge_type');
            $data = $this->unicon->CoreQuery("SELECT * FROM PO_CHARGES WHERE CHRG_TYPE LIKE '$poChargeType%'","row_array");
            echo json_encode(['po_charge_det'=>$data]);
        }

        public function getPaymentMethodByCode(){
            $poyMethCode = $this->input->post('pay_meth_code');
            $data = $this->unicon->CoreQuery("SELECT * FROM PAY_METHODS WHERE PM_CODE LIKE '$poyMethCode%'","row");
            echo json_encode(['pay_meth_det'=>$data]);
        }

        public function getCurExhRateByCurCode(){
            $curCodeNdName = $this->input->post('cur_exh_code');
            $data = $this->unicon->CoreQuery("SELECT *
                                                FROM CURRENCY
                                                JOIN CURRENCY_EXCHANGE_RATE
                                                ON CURRENCY_EXCHANGE_RATE.EXCHR_CURRENCY = CURRENCY.CUR_CODE
                                                WHERE CURRENCY.CUR_CODE LIKE '%$curCodeNdName%' 
                                                OR
                                                CURRENCY.CUR_NAME LIKE '%$curCodeNdName%'
                                                ORDER BY CURRENCY_EXCHANGE_RATE.EXCHR_CRE_DATE DESC
                                                LIMIT 1","row_array");
            echo json_encode(['cur_exh_det'=>$data]);
        }

        public function getitemDetByItemCode(){
            $itemCode = $this->input->post('item_code');
            $venCode = $this->input->post('v_code');
            $data = itemDetails($itemCode,1,$venCode);
            echo json_encode(['item_det'=>$data]);
        }
        public function getItemDelWithPurPriceByItemCode(){
            $itemCode = $this->input->post('item_code');
            $data = itemPriceDet($itemCode);
            $landCost = freightChargeDets($data->POH_PREFIX.$data->POH_ORDER_ID,'BUYER',"SUM(PODC_PO_CHARGE_AMT) AS TOT_LANDED_COST",'row');
            $itemDisPer = $data->POD_UNIT_COST/$data->POH_GRAND_TOTAL;
            $landedCostPerItem = $landCost->TOT_LANDED_COST * $itemDisPer;
            $ItemPriceWithLandedCost = $landedCostPerItem + ($data->POD_UNIT_COST * $data->POD_EXCH_RATE);
            
            echo json_encode(['item_det'=>$data,"unt_price_sar"=>floattwo($ItemPriceWithLandedCost*$data->I_COST_MULTIPLIER)]);
        }


        public function getPoPrefix(){
            header('Content-Type: application/json');
            $preType = $this->input->post('pre_type')?$this->input->post('pre_type'):null;
            $data = poPrefixes($preType);
            echo json_encode($data);
        }

        public function getLandingCostByOrderid(){

            $orderId = $this->input->post('order_id');
            $FreightData = freightChargeDets($orderId,"BUYER");
            $purItemDelData = purchaseOrderItemDet($orderId);
            $purHeaderDetData = purchaseOrderHeaderDet($orderId);
            $clearanceDetData = clearancDet($orderId);

            echo json_encode([
                                "landing_det" =>$FreightData,
                                "pur_item_det" =>$purItemDelData,
                                "pur_header_det" =>$purHeaderDetData,
                                "clearance_det" =>$clearanceDetData,
                            ]);
        }

        public function getWharehouseDet(){

            $whseCode = $this->input->post('whse_code');

            $whareHouseDet = wherehouseDetail(["where" =>"WHERE WHSE_CODE LIKE '$whseCode%'","dataType" => "row"]);

            echo json_encode([
                                "whse_det" =>$whareHouseDet,
                            ]);
        }

        public function getTransResnByCode(){

            $transResnCode = $this->input->post('trans_resn_code');

            $transResnDet = transReason(["where" =>"WHERE TR_TRANS_RSN LIKE '$transResnCode%'","dataType" => "row"]);

            echo json_encode([
                                "trans_resn_det" =>$transResnDet,
                            ]);
        }

        public function getTransRuleByCode(){

            $transRuleCode = $this->input->post('trans_rule_code');

            $transRuleDet = transRule(["where" =>"WHERE TRULE_TRANS_RULE LIKE '$transRuleCode%'","dataType" => "row"]);

            echo json_encode([
                                "trans_rule_det" =>$transRuleDet,
                            ]);
        }

        public function getItemStockQty(){
            $itemCode = $this->input->post('item_code');
            $whseCode = $this->input->post('from_whse_code');
            $stockReasn = $this->input->post('stk_resn');
            $searchType = $this->input->post('serach_type');
            $searchType = isset($searchType)?$searchType:null;

            $data = itemDetails($itemCode,1);

            $temp_list_price = itemUnitCost(["where" => "WHERE INVCOST_ITEM_CODE = '{$data[0]['I_CODE']}' ORDER BY INVCOST_ID DESC", "dataType" => "row"]);

            if ($temp_list_price) {
                $list_price = $temp_list_price->INVCOST_ACT_COST;
            }else{
                $list_price = null;
            }
            
            if ($stockReasn == 200) {
                $stockCon = 'no_limit';
            }elseif ($stockReasn == 201) {
                $stockCon = 'limit';
            }elseif ($stockReasn == 202) {
                $stockCon = 'limit';
            }elseif ($stockReasn == 204) {
                $stockCon = 'no_limit';
            }
            $stock_check = array();
            if ($data) {
                if ($searchType == 'sale') {
                    $whseDets = wherehouseDetail(['where' => "WHERE WHSE_CODE LIKE '$whseCode%'", 'dataType' => 'result']);
                    foreach ($whseDets as $whseDet) {
                        $item_P = array(
                            "dataType" => 'row',
                            "itemCode" => $data[0]['I_CODE'],
                            "whseId" => $whseDet->WHSE_CODE,
                        );
                        $stockDet = itemStockDet($item_P);
                        if($stockDet>0){
                            $stock_check['stock'] = $stockDet;
                            $stock_check['whse_code'] = $whseDet->WHSE_CODE;
                            break;
                        }
                    }
                }else{
                    $item_P = array(
                        "dataType" => 'row',
                        "itemCode" => $data[0]['I_CODE'],
                        "whseId" => $whseCode,
                    );
                    $stockDet = itemStockDet($item_P);
                }
                
                $list_price = $data[0]['I_LIST_PRICE']>0?$data[0]['I_LIST_PRICE']:$list_price;
            }else{
                $stockDet = 0;
            }

            
            

            echo json_encode([
                            'item_det' => $data,
                            'stock_det' => $stockDet,
                            'stock_con' => $stockCon,
                            "temp_list_price" => $list_price,
                            "sale_stock_det" => $stock_check,
                        ]);
        }

        public function getItemUntCost(){

            $itemCode = $this->input->post('item_code');
            $itemCostDet = itemUnitCost(["where" =>"WHERE INVCOST_ITEM_CODE = '$itemCode' ORDER BY INVCOST_ID DESC LIMIT 1","dataType" => "result"]);
            echo json_encode([
                                "item_cost_det" =>$itemCostDet,
                            ]);
        }

        public function getPriceChangerDetail(){

            $docNo = $this->input->post('doc_no');
            $priceChangerDel = priceChnagerDetail(["where" =>"WHERE PCD_DOCUMENT_NO = '$docNo'","dataType" => "result"]);
            echo json_encode([
                                "price_changer_del" =>$priceChangerDel,
                            ]);
        }


        // public function getTraitByItemCode(){
        //     $itemCode = $this->input->post('itemCode');

        //     $itemDel = $this->unicon->CoreQuery("SELECT * FROM ITEMS WHERE I_CODE='$itemCode'","result_array");

        //     $data = $this->unicon->CoreQuery("SELECT * FROM ITEMS as I
        //                                                 JOIN ITEM_TRAITS AS IT
        //                                                 WHERE I.I_CODE='$itemCode'","result_array");

        //     echo json_encode(['traitDeaits'=>$data,'itemdel'=>count($itemDel)==1?$itemDel:NULL]);
        // }

        /**========================================================================
         *                           PAYMENT VOUCHER TABLE LIST
         *========================================================================**/

         /*================================ PAYMENTOUT TABLE LIST ==============================*/
            
         public function paymentOutListJson(){
            $pvType = $this->input->post('pv_type');

            $sqlQueryTemp = array(

                "SELECT"=>'*',
                "FROM"=>'PAYMENT_VOCHER',

                "JOIN_1_CONTROL"=>TRUE,  // TABLE JOINING CONTROL TRUE ENABLE AND FALSE DISABLE DEFAULT VALUE FALSE
                    "JOIN_1_TABLE_NAME"=>'PAY_METHODS',
                    "JOIN_1_TABLE_CONN"=>'PAY_METHODS.PM_CODE=PAYMENT_VOCHER.PV_PAY_METH',

                "JOIN_3_CONTROL"=>TRUE,  // TABLE JOINING CONTROL TRUE ENABLE AND FALSE DISABLE DEFAULT VALUE FALSE
                    "JOIN_3_TABLE_NAME"=>'USERS',
                    "JOIN_3_TABLE_CONN"=>'USERS.ID=PAYMENT_VOCHER.PV_CRE_BY',

                "JOIN_4_CONTROL"=>FALSE,  // TABLE JOINING CONTROL TRUE ENABLE AND FALSE DISABLE DEFAULT VALUE FALSE
                    "JOIN_4_TABLE_NAME"=>'CLEARANCE_PO_ID',
                    "JOIN_4_TABLE_CONN"=>'CLEARANCE_PO_ID.CPO_TEMP_CL_ID=PO_HEADER.POH_TEMP_ORDER_ID',
                
                "JOIN_5_CONTROL"=>FALSE,  // TABLE JOINING CONTROL TRUE ENABLE AND FALSE DISABLE DEFAULT VALUE FALSE
                    "JOIN_5_TABLE_NAME"=>'CLEARANCE_ID',
                    "JOIN_5_TABLE_CONN"=>'CLEARANCE_ID.INV_CL_NO = CLEARANCE_PO_ID.CPO_CL_NO',
                
                "WHERE_1_CONTROL"=>TRUE,  // TABLE WHERE CLOUSE CONTROL TRUE ENABLE AND FALSE DISABLE DEFAULT VALUE FALSE
                    "WHERE_1_COL_NAME"=>'PAYMENT_VOCHER.PV_TYPE',
                    "WHERE_1_DATA"=>$pvType,
            );
            if ($pvType == 'VENDOR') {
                   $sqlQueryTemp["JOIN_2_CONTROL"] = TRUE;  // TABLE JOINING CONTROL TRUE ENABLE AND FALSE DISABLE DEFAULT VALUE FALSE
                   $sqlQueryTemp["JOIN_2_TABLE_NAME"] = 'VENDOR';
                   $sqlQueryTemp["JOIN_2_TABLE_CONN"] = 'VENDOR.V_CODE=PAYMENT_VOCHER.PV_PARTIES_CODE';

                   $filterdata = array(
                    "column_order" => array(NULL,'V_NAME','PV_ORDER_NO','PV_CRE_BY','PV_DESC','PV_AMT',NULL),
                    "column_search" => array('V_NAME','PV_ORDER_NO','PV_CRE_BY','PV_DESC','PV_AMT'),
                    "order" => array('PAYMENT_VOCHER.PV_ID' => 'DESC')
                );

            }elseif ($pvType == 'CUSTOMER') {
                   $sqlQueryTemp["JOIN_2_CONTROL"] = TRUE;  // TABLE JOINING CONTROL TRUE ENABLE AND FALSE DISABLE DEFAULT VALUE FALSE
                   $sqlQueryTemp["JOIN_2_TABLE_NAME"] = 'CUSTOMER';
                   $sqlQueryTemp["JOIN_2_TABLE_CONN"] = 'CUSTOMER.CUST_CODE=PAYMENT_VOCHER.PV_PARTIES_CODE';

                   $filterdata = array(
                    "column_order" => array(NULL,'CUST_NAME','PV_ORDER_NO','PV_CRE_BY','PV_DESC','PV_AMT',NULL),
                    "column_search" => array('CUST_NAME','PV_ORDER_NO','PV_CRE_BY','PV_DESC','PV_AMT'),
                    "order" => array('PAYMENT_VOCHER.PV_ID' => 'DESC')
                );
            }
            $sqlQuery = datatableSqlData($sqlQueryTemp);
            $memData = $this->datatableCon->getRows($_POST,$sqlQuery,$filterdata);

            $data = array();
            $no = $this->input->post('start');
            foreach ($memData as $rowdata) {
                $no++; $row = array();
                $row[] = $no.".";
                if ($pvType == 'VENDOR') {
                    $partyNameEng = $rowdata->V_NAME;
                    $partyNameAr = $rowdata->V_NAME_AR;
                    $vouchType = 'P';
                }elseif ($pvType == 'CUSTOMER') {
                    $partyNameEng = $rowdata->CUST_NAME;
                    $partyNameAr = $rowdata->CUST_NAME_AR;
                    $vouchType = 'S';

                }
                $vouchNo = dataEncypt($rowdata->PV_ORDER_NO,'encrypt');
                $row[] = "{$partyNameEng}</br>{$partyNameAr}"; 
                $row[] = "{$rowdata->PV_ORDER_NO}";
                $row[] = "{$rowdata->PV_DATE}";
                $row[] = "{$rowdata->PV_DESC}";
                $row[] = "{$rowdata->PV_AMT}";
                $row[] = "{$rowdata->NAME}";
                // $row[] = '<div class="d-flex gap-3">
                //             <a href="javascript:void(0);" class="text-success"><i class="mdi mdi-pencil font-size-18"></i></a>
                //             <a href="javascript:void(0);" class="text-danger"><i class="mdi mdi-delete font-size-18"></i></a>
                //         </div>';
                $prtUrl = base_url("voucherPrint?vouc-no=$vouchNo&vouc-type=$vouchType");
                $row[] = "<div class='d-flex gap-3'>
                    <a href='{$prtUrl}' class='text-success'><i class='fa fa-print font-size-18'></i></a>
                    <a href='javascript:void(0);' class='text-danger'><i class='fa fa-trash font-size-18'></i></a>
                </div>";
                
                $data[] = $row;
            }
            $output = array(
                "draw" => empty($this->input->post('draw')) ? 'none' : $this->input->post('draw'),
                "recordsTotal" => $this->datatableCon->countAll($sqlQuery),
                "recordsFiltered" => $this->datatableCon->countFiltered($_POST,$sqlQuery),
                "data" => $data
            );
            //output to json format
            header('Content-Type: application/json');
            echo json_encode($output);
        }
    }