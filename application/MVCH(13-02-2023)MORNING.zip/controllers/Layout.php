<?php
     class Layout extends CI_Controller{
         public function __construct(){
            parent::__construct();
      
            // $this->load->model('Site_model', 'dbcon');
            // $this->load->model('Universal_model','unicon');
            // $this->load->library('form_validation');
            // $this->load->helper('form');
            //$this->load->model('QrController','qrcon');
         }
        public function logout(){
            $newdata = array('login'=>false,'userId'=>'');
            $this->session->unset_userdata($newdata);
            $this->session->sess_destroy();
            redirect(base_url(),'refresh');
        }

        public function index(){
            sessionCheck('login');
            $this->load->view('layout/login');
        }
        // <!-- dashboard -->
         public function dashboard(){
            sessionCheck();
            $this->load->view('layout/header');
            $this->load->view('layout/dashboard');
            $this->load->view('layout/footer');
        }
        
        
        
        // <!-- Add Parties -->
        public function CustomerAdd(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['countryLists'] = countryList();
            $data['custTypeDets'] = custTypeDet(['dataType'=>'result']);
            $this->load->view('layout/header');
            $this->load->view('layout/parties/CustomerAdd',$data);
            $this->load->view('layout/footer');
        }
        
        public function CustomerList(){
            sessionCheck();
            $this->load->view('layout/header');
            $this->load->view('layout/parties/CustomerList');
            $this->load->view('layout/footer');
        }
        
        public function VendorAdd(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['countryLists'] = countryList();
            $data['currencyLists'] = currencyList();
            $this->load->view('layout/header');
            $this->load->view('layout/parties/VendorAdd',$data);
            $this->load->view('layout/footer');
        }
        
        public function VendorList(){
            sessionCheck();
            $this->load->view('layout/header');
            $this->load->view('layout/parties/VendorList');
            $this->load->view('layout/footer');
        }
        
        
        
        //############# <!-- Add Product -->###############
        public function ProductAdd(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['uomLists'] = uomList();
            $data['classLists'] = classList();
            $data['categoryLists'] = categoryList();
            $data['vendorLists'] = vendorList();
            $data['countryLists'] = countryList();
            $this->load->view('layout/header');
            $this->load->view('layout/product/ProductsAdd',$data);
            $this->load->view('layout/footer');

        }
        
        public function ProductList(){
            sessionCheck();
            $this->load->view('layout/header');
            $this->load->view('layout/product/ProductList');
            $this->load->view('layout/footer');

        }
        
         public function ProductDetail(){
            sessionCheck();
            
            $itemCode = dataEncypt($this->input->get('item_code'),'decrypt')?dataEncypt($this->input->get('item_code'),'decrypt'):dataEncyptManual($this->input->get('item_code_bak'),'decrypt');

            $itemDets = itemDetails($itemCode);
          
            if($itemDets){
                $data['itemDets'] = $itemDets;
                $data['whseDets'] = wherehouseDetail(['dataType'=>'result']);
                $this->load->view('layout/header');
                $this->load->view('layout/product/ProductDetail',$data);
                $this->load->view('layout/footer');
            }else{
                redirect(base_url('ProductList'), 'refresh');
            }   
            // $data['itemCode'] = 

            

        }
        
        
        //############### <!-- Add Sals -->###################
        
        public function SaleAdd(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['countryLists'] = countryList();
            $data['custTypeDets'] = custTypeDet(['dataType'=>'result']);
            $data['js_min_con'] = FALSE;
            $data['whareDets'] = wherehouseDetail(['where'=>"WHERE WHSE_LOCATION_TYPE = 'SL'",'dataType' => 'result']);
            $this->load->view('layout/header');
            $this->load->view('layout/sale/SaleAdd',$data);
            $this->load->view('layout/footer',$data);

        }
        
        public function SaleInvoice(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/sale/SaleInvoice');
            $this->load->view('layout/footer');

        }
        
        public function SaleReturn(){
            sessionCheck();

            $data['sweetAlertMsg'] = sweetAlertMsg();

            $orderId = dataEncyptbase64($this->input->get('orderid'),'decrypt')?dataEncyptbase64($this->input->get('orderid'),'decrypt'):null;
            
            $OrderDetHed = saleOrderHeadDet(["where"=>"AND SH_ORDER_ID='$orderId'","dataType"=>"row"]);
            $OrderDetHed?$OrderDetHed:redirect(base_url('dashboard'), 'refresh');
            //* SALE RETURN --> DATA FETCH
            $data['headerDet'] = $OrderDetHed;
            // print_r($data['headerDet']);

            $data['payDets'] = paymentDetails(["where"=>"AND PD_ORDER_ID='$orderId'","dataType"=>"result"]);
            // print_r($data['payDets']);
            //

            $data['countryLists'] = countryList();
            $data['custTypeDets'] = custTypeDet(['dataType'=>'result']);
            $data['js_min_con'] = FALSE;
            $data['whareDets'] = wherehouseDetail(['where'=>"WHERE WHSE_LOCATION_TYPE = 'SL'",'dataType' => 'result']);
            $this->load->view('layout/header');
            $this->load->view('layout/sale/SaleReturn',$data);
            $this->load->view('layout/footer');

        }
        
        public function Payment(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['js_min_con'] = FALSE;
            $this->load->view('layout/header');
            $this->load->view('layout/sale/Payment',$data);
            $this->load->view('layout/footer',$data);

        }
        
        
        public function SaleOrderList(){
            sessionCheck();

            $data['saleType'] = 'order';

            $this->load->view('layout/header');
            $this->load->view('layout/sale/SaleList',$data);
            $this->load->view('layout/footer');

        }

        public function SaleInvoiceList(){
            sessionCheck();

            $data['saleType'] = 'invoice';

            $this->load->view('layout/header');
            $this->load->view('layout/sale/SaleList',$data);
            $this->load->view('layout/footer');

        }
        
         public function SaleView(){
            sessionCheck();

            $orderId = dataEncyptbase64($this->input->get('orderid'),'decrypt')?dataEncyptbase64($this->input->get('orderid'),'decrypt'):null;

            // purchaseOrderHeaderDet($orderId,'num_rows')>0?null:redirect(base_url('PurchaseList'), 'refresh');

            $data['orderId'] = $orderId;
            $data['headerDet'] = saleOrderHeadDet(["where"=>"AND SH_ORDER_ID='$orderId'","dataType"=>"row"]);
            $data['detailsLists'] = saleOrderLineDet(["where"=>"AND SD.SD_ORDER_ID='$orderId'","dataType"=>"result"]);
            $data['payDets'] = paymentDetails(["where"=>"AND PD_ORDER_ID='$orderId'","dataType"=>"result"]);
            // $data['clearanceDet'] = clearancDet($orderId,'row');
            $data['busUnit'] = busUnitDetail();
            
             
            $this->load->view('layout/header');
            $this->load->view('layout/sale/SaleView',$data);
            $this->load->view('layout/footer');

        }
        
         public function SaleReturnList(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/sale/SaleReturnList');
            $this->load->view('layout/footer');

        }
        
         public function PaymentList(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/sale/PaymentList');
            $this->load->view('layout/footer');

        }
        
// ############<!-- Purchase -->##################
        
        
        public function PurchaseAdd(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $this->load->view('layout/header');
            $this->load->view('layout/purchase/PurchaseAdd',$data);
            $this->load->view('layout/footer');

        }
        
        
        public function PurchaseOrderList(){
            sessionCheck();

            $data['purchaseType'] = 'order';
            $this->load->view('layout/header');
            $this->load->view('layout/purchase/PurchaseList',$data);
            $this->load->view('layout/footer');

        }

        public function PurchaseView(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $orderId = dataEncypt($this->input->get('orderid'),'decrypt')?dataEncypt($this->input->get('orderid'),'decrypt'):dataEncyptManual($this->input->get('bakOrderid'),'decrypt');

            purchaseOrderHeaderDet($orderId,'num_rows')>0?null:redirect(base_url('PurchaseList'), 'refresh');

            $data['orderId'] = $orderId;
            $data['headerDet'] = purchaseOrderHeaderDet($orderId,"row");
            $data['poItemDets'] = purchaseOrderItemDet($orderId);
            $data['poCharges'] = freightChargeDets($orderId,"SELLER");
            $data['clearanceDet'] = clearancDet($orderId,'row');
            $data['busUnit'] = busUnitDetail();

            $this->load->view('layout/header');
            $this->load->view('layout/purchase/PurchaseView',$data);
            $this->load->view('layout/footer');

        }
        
        public function PurchaseInvoice(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/purchase/PurchaseInvoice');
            $this->load->view('layout/footer');

        }
        
         public function PriceChanger(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/purchase/PriceChanger');
            $this->load->view('layout/footer');

        }
        
        public function PriceChangerView(){
            sessionCheck();
            $this->load->view('layout/header');
            $this->load->view('layout/purchase/PriceChangerView');
            $this->load->view('layout/footer');

        }
        
         public function landingCost(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $orderId = dataEncypt($this->input->get('orderid'),'decrypt')?dataEncypt($this->input->get('orderid'),'decrypt'):dataEncyptManual($this->input->get('bakOrderid'),'decrypt');
            purchaseOrderHeaderDet($orderId,'num_rows')>0?null:redirect(base_url('PurchaseList'), 'refresh');
            $data['orderid'] = $orderId;
            $this->load->view('layout/header');
            $this->load->view('layout/purchase/LandingCost',$data);
            $this->load->view('layout/footer');

        }
        
        public function PurchaseInvoiceList(){
            sessionCheck();

            $data['purchaseType'] = 'invoice';
            $this->load->view('layout/header');
            $this->load->view('layout/purchase/PurchaseList',$data);
            // $this->load->view('layout/purchase/PurchaseInvoiceList');
            $this->load->view('layout/footer');

        }
        
         public function PurchaseReturn(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/purchase/PurchaseReturn');
            $this->load->view('layout/footer');

        }
        
         public function PurchaseReturnList(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/purchase/PurchaseReturnList');
            $this->load->view('layout/footer');

        }
        
         public function PaymentOut(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['js_min_con'] = FALSE;
            $this->load->view('layout/header');
            $this->load->view('layout/purchase/PaymentOut',$data);
            $this->load->view('layout/footer',$data);

        }
        
        public function voucherPrint(){
            $vochNo = $this->input->get('vouc-no');
            $vouchType = $this->input->get('vouc-type');
            $vochNo = dataEncypt($vochNo, 'decrypt');
            if ($vouchType == 'P') {
                $detail = $this->unicon->CoreQuery("SELECT *,V_NAME AS V_NAME,V_NAME_AR AS V_NAME_AR FROM PAYMENT_VOCHER PV,PAY_METHODS PM,VENDOR V
                                                WHERE PM_CODE = PV_PAY_METH AND V_CODE = PV_PARTIES_CODE
                                                AND PV_ORDER_NO='$vochNo'","row");
                $data['detail'] = $detail?$detail:redirect(base_url('PaymentOut'),'refresh');
                $data['head'] = "PAYMENT OUT";
            }elseif ($vouchType == 'S') {
                $detail = $this->unicon->CoreQuery("SELECT *,CUST_NAME AS V_NAME,CUST_NAME_AR AS V_NAME_AR FROM PAYMENT_VOCHER PV,PAY_METHODS PM,CUSTOMER C
                                                WHERE PM_CODE = PV_PAY_METH AND CUST_CODE = PV_PARTIES_CODE
                                                AND PV_ORDER_NO='$vochNo'","row");
                $data['detail'] = $detail?$detail:redirect(base_url('Payment'),'refresh');
                $data['head'] = "PAYMENT IN";
            }else{
                redirect(base_url(),'refresh');
            }
            
            $this->load->view('layout/sale/Voucher',$data);
      
        }
        
         public function PaymentOutList(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/purchase/PaymentOutList');
            $this->load->view('layout/footer');

        }
        
        
// ############<!-- Users -->##################

        public function addItemTrait(){
            sessionCheck();
            if($this->input->get('type') == 'view'){
                $itemCode = dataEncypt($this->input->get('item_code'), 'decrypt') ? dataEncypt($this->input->get('item_code'), 'decrypt') : dataEncyptManual($this->input->get('item_code_bak'),'decrypt');
                $data['itemCode'] = $itemCode;

            }else{
                $itemCode = dataEncypt($this->input->get('item_code'), 'decrypt') ? dataEncypt($this->input->get('item_code'), 'decrypt') : dataEncyptManual($this->input->get('item_code_bak'),'decrypt');
                $data['itemCode'] = $itemCode;
                // $data['itemCode'] = $this->encryption->decrypt($this->session->userdata('item_code'));
            }

            $this->load->view('layout/header');
            $this->load->view('layout/product/addItemTrait',$data);
            $this->load->view('layout/footer');

         }

// ############<!-- Inventory -->##################

        public function Inventory(){

            $this->load->view('layout/header');
            $this->load->view('layout/inventory/Inventory');
            $this->load->view('layout/footer');

         }
         
          public function StockTransfer(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $this->load->view('layout/header');
            $this->load->view('layout/inventory/StockTransfer',$data);
            $this->load->view('layout/footer');

         }
         
          public function StockRecevied(){

            $this->load->view('layout/header');
            $this->load->view('layout/inventory/StockRecevied');
            $this->load->view('layout/footer');

         }
         
         public function StockTransferView(){
            sessionCheck();
            $orderId = dataEncyptbase64($this->input->get('orderid'),'decrypt');

            $stockTransferOrderDets = StockTransferOrderDet(["where" => "WHERE STH_ORDER_NO = '$orderId'", "dataType" => 'result']);

            $data['stockTransferOrderDets'] = count($stockTransferOrderDets)>0?$stockTransferOrderDets:redirect(base_url('StockTransferList'),'refresh');
            $data['wharehouseFrom'] = wherehouseDetail(["where"=>"WHERE WHSE_CODE = '{$data['stockTransferOrderDets'][0]->STH_FROM_WHSE}'","dataType"=>'row']);
            $data['wharehouseto'] = wherehouseDetail(["where"=>"WHERE WHSE_CODE = '".$data['stockTransferOrderDets'][0]->STH_WHSE_TO."'","dataType"=>'row']);
        
            $this->load->view('layout/header');
            $this->load->view('layout/inventory/StockTransferView',$data);
            $this->load->view('layout/footer');

         }
         
          public function StockAdjustment(){

            $this->load->view('layout/header');
            $this->load->view('layout/inventory/StockAdjustment');
            $this->load->view('layout/footer');

         }
         
          public function PhysicalInventory(){

            $this->load->view('layout/header');
            $this->load->view('layout/inventory/PhysicalInventory');
            $this->load->view('layout/footer');

         }
         
          public function InventoryList(){
            sessionCheck();
            
            $data['whareDets'] = wherehouseDetail(['dataType' => 'result']);
            $this->load->view('layout/header');
            $this->load->view('layout/inventory/InventoryList',$data);
            $this->load->view('layout/footer');

         }
         
          public function StockTransferList(){
            sessionCheck();
            $this->load->view('layout/header');
            $this->load->view('layout/inventory/StockTransferList');
            $this->load->view('layout/footer');

         }
         
          public function StockReceviedList(){

            $this->load->view('layout/header');
            $this->load->view('layout/inventory/StockReceviedList');
            $this->load->view('layout/footer');

         }
         
          public function StockAdjustmentList(){

            $this->load->view('layout/header');
            $this->load->view('layout/inventory/StockAdjustmentList');
            $this->load->view('layout/footer');

         }
         
          public function PhysicalInventoryList(){

            $this->load->view('layout/header');
            $this->load->view('layout/inventory/PhysicalInventoryList');
            $this->load->view('layout/footer');

         }


// ############<!-- Users -->##################
        
        public function EmployeesAdd(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['countryLists'] = countryList();
            $data['busUnits'] = busUnit();
            $data['empCats'] = empCat();
            $this->load->view('layout/header');
            $this->load->view('layout/users/EmployeesAdd',$data);
            $this->load->view('layout/footer');
        }
        
        
        public function EmployeesList(){
            sessionCheck();
            $this->load->view('layout/header');
            $this->load->view('layout/users/EmployeesList');
            $this->load->view('layout/footer');
        }
        
        
        public function SalesManAdd(){
            sessionCheck();
            
            $data['js_min_con'] = FALSE;

            $data['busUnits'] = busUnit();
            $data['saleAreas'] = salesArea();
            $data['whareDets'] = wherehouseDetail(['dataType' => 'result']);
            $this->load->view('layout/header');
            $this->load->view('layout/users/SalesManAdd',$data);
            $this->load->view('layout/footer',$data);
        }
        
        
        public function SalesManList(){
            sessionCheck();
            $this->load->view('layout/header');
            $this->load->view('layout/users/SalesManList');
            $this->load->view('layout/footer');
        }
        
        
        // ############<!-- Reports -->##################
        
        
        public function Payments(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/reports/Payments');
            $this->load->view('layout/footer');

        }
        
        
        public function ProductReport(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/reports/ProductReport');
            $this->load->view('layout/footer');

        }
        
        public function PurchaseReport(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/reports/PurchaseReport');
            $this->load->view('layout/footer');

        }
        
        public function SaleReport(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/reports/SaleReport');
            $this->load->view('layout/footer');

        }

// ############<!-- Master -->##################
       
        public function BusinessUnitList(){
            sessionCheck();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/BusinessUnitList');
            $this->load->view('layout/footer');

        }

        public function BusinessUnitAdd(){
            sessionCheck();
            $data['countryLists'] = countryList();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/BusinessUnitAdd',$data);
            $this->load->view('layout/footer');

        }
        
        public function WarehouseList(){
            sessionCheck();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/WarehouseList');
            $this->load->view('layout/footer');

        }

        public function WarehouseAdd(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['busUnits'] = busUnit();
            $data['countryLists'] = countryList();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/WarehouseAdd',$data);
            $this->load->view('layout/footer');

        }
        

        public function CountryList(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['currencyLists'] = currencyList();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/country',$data);
            $this->load->view('layout/footer');
        }

        public function stateList(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['countryLists'] = countryList();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/stateList',$data);
            $this->load->view('layout/footer');
        }

        public function CountryAdd(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/setting/add/country_add');
            $this->load->view('layout/footer');

        }

        // Currency

        public function CurrencyList(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/CurrencyList',$data);
            $this->load->view('layout/footer');

        }
        
        public function CurrencyExList(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['currencyLists'] = currencyList();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/CurrencyExList',$data);
            $this->load->view('layout/footer');

        }
        
        
         public function CityList(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['stateLists'] = stateList();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/CityList',$data);
            $this->load->view('layout/footer');

        }

        public function CityAdd(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/setting/add/CityAdd');
            $this->load->view('layout/footer');

        }
        
        public function UOMList(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['busUnits'] = busUnit();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/UOMList',$data);
            $this->load->view('layout/footer');

        }

        public function UOMAdd(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/setting/add/UOMAdd');
            $this->load->view('layout/footer');

        }
        
        public function ItemCategoryList(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['busUnits'] = busUnit();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/ItemCategoryList',$data);
            $this->load->view('layout/footer');

        }
        
        
         public function ShipList(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['busUnits'] = busUnit();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/ShipList',$data);
            $this->load->view('layout/footer');

        }

        // public function ItemCategoryAdd(){
            
        //     $this->load->view('layout/header');
        //     $this->load->view('layout/setting/add/ItemCategoryAdd');
        //     $this->load->view('layout/footer');

        // }
        
        public function ItemClassList(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['busUnits'] = busUnit();
            $data['categoryLists'] = categoryList();
            $data['uomLists'] = uomList();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/ItemClassList',$data);
            $this->load->view('layout/footer');

        }

        // public function ItemClassAdd(){
            
        //     $this->load->view('layout/header');
        //     $this->load->view('layout/setting/add/ItemClassAdd');
        //     $this->load->view('layout/footer');

        // }
        
        public function PasswordList(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['busUnits'] = busUnit();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/PasswordList',$data);
            $this->load->view('layout/footer');
        }
        
        public function PasswordUsedList(){
            $data['busUnits'] = busUnit();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/PasswordUsedList',$data);
            $this->load->view('layout/footer');

        }

        public function TraiteCategoryList(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['busUnits'] = busUnit();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/TraiteCategoryList',$data);
            $this->load->view('layout/footer');

        }

        public function TraiteCategoryAdd(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/setting/add/TraiteCategoryAdd');
            $this->load->view('layout/footer');

        }
        
        
         public function TraitesList(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['traitCatLists'] = traitCatList();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/TraitesList',$data);
            $this->load->view('layout/footer');

        }

        public function TraitesAdd(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/setting/add/TraitesAdd');
            $this->load->view('layout/footer');

        }
        



        public function PaymentMethodList(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/PaymentMethodList',$data);
            $this->load->view('layout/footer');

        }

        public function PaymentMethodAdd(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/setting/add/PaymentMethodAdd');
            $this->load->view('layout/footer');
        }
        
         public function BankList(){
            
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['busUnits'] = busUnit();
            $data['bankDet'] = bankDet();
            $data['countryLists'] = countryList();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/BankList',$data);
            $this->load->view('layout/footer');

        }

        public function BankAdd(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/setting/add/BankAdd');
            $this->load->view('layout/footer');

        }
        

        public function POChargesList(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/POChargesList',$data);
            $this->load->view('layout/footer');

        }
        
         public function FOBList(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['busUnits'] = busUnit();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/FOBList',$data);
            $this->load->view('layout/footer');

        }
        public function FreightList(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['busUnits'] = busUnit();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/FreightList',$data);
            $this->load->view('layout/footer');

        }

        public function TermsList(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['busUnits'] = busUnit();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/TermsList',$data);
            $this->load->view('layout/footer');

        }
        
        public function POPrefixesList(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['busUnits'] = busUnit();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/POPrefixesList',$data);
            $this->load->view('layout/footer');

        }
        public function FiscalYearsList(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['busUnits'] = busUnit();
            $data['fYearList'] = fYearList();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/FiscalYearsList',$data);
            $this->load->view('layout/footer');

        }
        public function FiscalPeriodsList(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['busUnits'] = busUnit();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/FiscalPeriodsList',$data);
            $this->load->view('layout/footer');

        }
        public function GLPrefixesList(){
            sessionCheck();
            $data['sweetAlertMsg'] = sweetAlertMsg();
            $data['busUnits'] = busUnit();
            $data['glPrefix'] = glPrefix();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/GLPrefixesList',$data);
            $this->load->view('layout/footer');

        }
        
    }