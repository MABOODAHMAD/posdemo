<?php
     class Layout extends CI_Controller{
         public function __construct(){
            parent::__construct();
      
            // $this->load->model('Site_model', 'dbcon');
            // $this->load->model('Universal_model','unicon');
            // $this->load->library('form_validation');
            // $this->load->helper('form');
            //$this->load->model('QrController','qrcon');
         }
        public function logout(){
            $newdata = array('login'=>false,'userId'=>'');
            $this->session->unset_userdata($newdata);
            $this->session->sess_destroy();
            redirect(base_url(),'refresh');
        }

        public function index(){
            sessionCheck('login');
            $this->load->view('layout/login');
        }
        // <!-- dashboard -->
         public function dashboard(){
            sessionCheck();
            $this->load->view('layout/header');
            $this->load->view('layout/dashboard');
            $this->load->view('layout/footer');
        }
        
        
        
        // <!-- Add Parties -->
        public function CustomerAdd(){
            sessionCheck();
            $this->load->view('layout/header');
            $this->load->view('layout/parties/CustomerAdd');
            $this->load->view('layout/footer');
        }
        
        public function CustomerList(){
            sessionCheck();
            $this->load->view('layout/header');
            $this->load->view('layout/parties/CustomerList');
            $this->load->view('layout/footer');
        }
        
        public function VendorAdd(){
            sessionCheck();
            $data['countryLists'] = countryList();
            $this->load->view('layout/header');
            $this->load->view('layout/parties/VendorAdd',$data);
            $this->load->view('layout/footer');
        }
        
        public function VendorList(){
            sessionCheck();
            $this->load->view('layout/header');
            $this->load->view('layout/parties/VendorList');
            $this->load->view('layout/footer');
        }
        
        
        
        //############# <!-- Add Product -->###############
        public function ProductAdd(){
            sessionCheck();
            $data['uomLists'] = uomList();
            $data['classLists'] = classList();
            $data['categoryLists'] = categoryList();
            $data['vendorLists'] = vendorList();
            $data['countryLists'] = countryList();
            $this->load->view('layout/header');
            $this->load->view('layout/product/ProductsAdd',$data);
            $this->load->view('layout/footer');

        }
        
        public function ProductList(){
            sessionCheck();
            $this->load->view('layout/header');
            $this->load->view('layout/product/ProductList');
            $this->load->view('layout/footer');

        }
        
         public function ProductDetail(){
            sessionCheck();
            $itemCode = dataEncypt($this->input->get('item_code'),'decrypt');
            $itemDets = itemDetails($itemCode);
          
            if($itemDets){
                $data['itemDets'] = $itemDets;
                $this->load->view('layout/header');
                $this->load->view('layout/product/ProductDetail',$data);
                $this->load->view('layout/footer');
            }else{
                redirect(base_url('ProductList'), 'refresh');
            }   
            // $data['itemCode'] = 

            

        }
        
        
        //############### <!-- Add Sals -->###################
        
        public function SaleAdd(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/sale/SaleAdd');
            $this->load->view('layout/footer');

        }
        
        public function SaleInvoice(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/sale/SaleInvoice');
            $this->load->view('layout/footer');

        }
        
        public function SaleReturn(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/sale/SaleReturn');
            $this->load->view('layout/footer');

        }
        
        public function Payment(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/sale/Payment');
            $this->load->view('layout/footer');

        }
        
        
        public function SaleList(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/sale/SaleList');
            $this->load->view('layout/footer');

        }
        
         public function SaleInvoiceList(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/sale/SaleInvoiceList');
            $this->load->view('layout/footer');

        }
        
         public function SaleReturnList(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/sale/SaleReturnList');
            $this->load->view('layout/footer');

        }
        
         public function PaymentList(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/sale/PaymentList');
            $this->load->view('layout/footer');

        }
        
// ############<!-- Purchase -->##################
        
        
        public function PurchaseAdd(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/purchase/PurchaseAdd');
            $this->load->view('layout/footer');

        }
        
        
        public function PurchaseList(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/purchase/PurchaseList');
            $this->load->view('layout/footer');

        }

        public function PurchaseView(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/purchase/PurchaseView');
            $this->load->view('layout/footer');

        }
        
        public function PurchaseInvoice(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/purchase/PurchaseInvoice');
            $this->load->view('layout/footer');

        }
        
         public function PriceChanger(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/purchase/PriceChanger');
            $this->load->view('layout/footer');

        }
        
         public function LandingCost(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/purchase/LandingCost');
            $this->load->view('layout/footer');

        }
        
        public function PurchaseInvoiceList(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/purchase/PurchaseInvoiceList');
            $this->load->view('layout/footer');

        }
        
         public function PurchaseReturn(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/purchase/PurchaseReturn');
            $this->load->view('layout/footer');

        }
        
         public function PurchaseReturnList(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/purchase/PurchaseReturnList');
            $this->load->view('layout/footer');

        }
        
         public function PaymentOut(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/purchase/PaymentOut');
            $this->load->view('layout/footer');

        }
        
         public function PaymentOutList(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/purchase/PaymentOutList');
            $this->load->view('layout/footer');

        }
        
        
// ############<!-- Users -->##################

        public function addItemTrait(){

            if($this->input->get('type') == 'view'){

                $data['itemCode'] = dataEncypt($this->input->get('item_code'),'decrypt');

            }else{
                print_r('Data=>'.dataEncypt($this->input->get('item_code'),'decrypt'));
                $data['itemCode'] = dataEncypt($this->input->get('item_code'),'decrypt');
                // $data['itemCode'] = $this->encryption->decrypt($this->session->userdata('item_code'));
            }

            $this->load->view('layout/header');
            $this->load->view('layout/product/addItemTrait',$data);
            $this->load->view('layout/footer');

         }

// ############<!-- Inventory -->##################

        public function Inventory(){

            $this->load->view('layout/header');
            $this->load->view('layout/inventory/Inventory');
            $this->load->view('layout/footer');

         }
         
          public function StockTransfer(){

            $this->load->view('layout/header');
            $this->load->view('layout/inventory/StockTransfer');
            $this->load->view('layout/footer');

         }
         
          public function StockRecevied(){

            $this->load->view('layout/header');
            $this->load->view('layout/inventory/StockRecevied');
            $this->load->view('layout/footer');

         }
         
          public function StockAdjustment(){

            $this->load->view('layout/header');
            $this->load->view('layout/inventory/StockAdjustment');
            $this->load->view('layout/footer');

         }
         
          public function PhysicalInventory(){

            $this->load->view('layout/header');
            $this->load->view('layout/inventory/PhysicalInventory');
            $this->load->view('layout/footer');

         }
         
          public function InventoryList(){

            $this->load->view('layout/header');
            $this->load->view('layout/inventory/InventoryList');
            $this->load->view('layout/footer');

         }
         
          public function StockTransferList(){

            $this->load->view('layout/header');
            $this->load->view('layout/inventory/StockTransferList');
            $this->load->view('layout/footer');

         }
         
          public function StockReceviedList(){

            $this->load->view('layout/header');
            $this->load->view('layout/inventory/StockReceviedList');
            $this->load->view('layout/footer');

         }
         
          public function StockAdjustmentList(){

            $this->load->view('layout/header');
            $this->load->view('layout/inventory/StockAdjustmentList');
            $this->load->view('layout/footer');

         }
         
          public function PhysicalInventoryList(){

            $this->load->view('layout/header');
            $this->load->view('layout/inventory/PhysicalInventoryList');
            $this->load->view('layout/footer');

         }


// ############<!-- Users -->##################
        
        
        public function EmployeesAdd(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/users/EmployeesAdd');
            $this->load->view('layout/footer');

        }
        
        
        public function EmployeesList(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/users/EmployeesList');
            $this->load->view('layout/footer');

        }
        
        
        // ############<!-- Reports -->##################
        
        
        public function Payments(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/reports/Payments');
            $this->load->view('layout/footer');

        }
        
        
        public function ProductReport(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/reports/ProductReport');
            $this->load->view('layout/footer');

        }
        
        public function PurchaseReport(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/reports/PurchaseReport');
            $this->load->view('layout/footer');

        }
        
        public function SaleReport(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/reports/SaleReport');
            $this->load->view('layout/footer');

        }

// ############<!-- Master -->##################
       
        public function BusinessUnitList(){
            sessionCheck();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/BusinessUnitList');
            $this->load->view('layout/footer');

        }

        public function BusinessUnitAdd(){
            sessionCheck();
            $data['countryLists'] = countryList();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/BusinessUnitAdd',$data);
            $this->load->view('layout/footer');

        }
        
        public function WarehouseList(){
            sessionCheck();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/WarehouseList');
            $this->load->view('layout/footer');

        }

        public function WarehouseAdd(){
            sessionCheck();
            $data['countryLists'] = countryList();
            $data['busUnits'] = busUnit();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/WarehouseAdd',$data);
            $this->load->view('layout/footer');

        }
        

        public function CountryList(){
            $data['currencyLists'] = currencyList();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/country',$data);
            $this->load->view('layout/footer');
        }

        public function stateList(){
            $data['countryLists'] = countryList();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/stateList',$data);
            $this->load->view('layout/footer');
        }

        public function CountryAdd(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/setting/add/country_add');
            $this->load->view('layout/footer');

        }

        // Currency

        public function CurrencyList(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/setting/CurrencyList');
            $this->load->view('layout/footer');

        }
        
        public function CurrencyExList(){
            
            $data['currencyLists'] = currencyList();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/CurrencyExList',$data);
            $this->load->view('layout/footer');

        }
        
        
         public function CityList(){
            $data['stateLists'] = stateList();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/CityList',$data);
            $this->load->view('layout/footer');

        }

        public function CityAdd(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/setting/add/CityAdd');
            $this->load->view('layout/footer');

        }
        
        public function UOMList(){

            $data['busUnits'] = busUnit();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/UOMList',$data);
            $this->load->view('layout/footer');

        }

        public function UOMAdd(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/setting/add/UOMAdd');
            $this->load->view('layout/footer');

        }
        
        public function ItemCategoryList(){
            $data['busUnits'] = busUnit();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/ItemCategoryList',$data);
            $this->load->view('layout/footer');

        }
        
        
         public function ShipList(){
            $data['busUnits'] = busUnit();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/ShipList',$data);
            $this->load->view('layout/footer');

        }

        // public function ItemCategoryAdd(){
            
        //     $this->load->view('layout/header');
        //     $this->load->view('layout/setting/add/ItemCategoryAdd');
        //     $this->load->view('layout/footer');

        // }
        
        public function ItemClassList(){
            $data['busUnits'] = busUnit();
            $data['categoryLists'] = categoryList();
            $data['uomLists'] = uomList();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/ItemClassList',$data);
            $this->load->view('layout/footer');

        }

        // public function ItemClassAdd(){
            
        //     $this->load->view('layout/header');
        //     $this->load->view('layout/setting/add/ItemClassAdd');
        //     $this->load->view('layout/footer');

        // }
        


        public function TraiteCategoryList(){
            $data['busUnits'] = busUnit();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/TraiteCategoryList',$data);
            $this->load->view('layout/footer');

        }

        public function TraiteCategoryAdd(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/setting/add/TraiteCategoryAdd');
            $this->load->view('layout/footer');

        }
        
        
         public function TraitesList(){
            $data['traitCatLists'] = traitCatList();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/TraitesList',$data);
            $this->load->view('layout/footer');

        }

        public function TraitesAdd(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/setting/add/TraitesAdd');
            $this->load->view('layout/footer');

        }
        



        public function PaymentMethodList(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/setting/PaymentMethodList');
            $this->load->view('layout/footer');

        }

        public function PaymentMethodAdd(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/setting/add/PaymentMethodAdd');
            $this->load->view('layout/footer');
        }
        
         public function BankList(){
            
            sessionCheck();
            $data['busUnits'] = busUnit();
            $data['bankDet'] = bankDet();
            $data['countryLists'] = countryList();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/BankList',$data);
            $this->load->view('layout/footer');

        }

        public function BankAdd(){
            
            $this->load->view('layout/header');
            $this->load->view('layout/setting/add/BankAdd');
            $this->load->view('layout/footer');

        }
        

        public function POChargesList(){
            sessionCheck();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/POChargesList');
            $this->load->view('layout/footer');

        }
        
         public function FOBList(){
             sessionCheck();
            $data['busUnits'] = busUnit();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/FOBList',$data);
            $this->load->view('layout/footer');

        }
        public function FreightList(){
            sessionCheck();
            $data['busUnits'] = busUnit();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/FreightList',$data);
            $this->load->view('layout/footer');

        }

        public function TermsList(){
            sessionCheck();
            $data['busUnits'] = busUnit();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/TermsList',$data);
            $this->load->view('layout/footer');

        }
        
        public function POPrefixesList(){
            sessionCheck();
            $data['busUnits'] = busUnit();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/POPrefixesList',$data);
            $this->load->view('layout/footer');

        }
        public function FiscalYearsList(){
            sessionCheck();
            $data['busUnits'] = busUnit();
            $data['fYearList'] = fYearList();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/FiscalYearsList',$data);
            $this->load->view('layout/footer');

        }
        public function FiscalPeriodsList(){
            sessionCheck();
            $data['busUnits'] = busUnit();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/FiscalPeriodsList',$data);
            $this->load->view('layout/footer');

        }
        public function GLPrefixesList(){
            sessionCheck();
            $data['busUnits'] = busUnit();
            $data['glPrefix'] = glPrefix();
            $this->load->view('layout/header');
            $this->load->view('layout/setting/GLPrefixesList',$data);
            $this->load->view('layout/footer');

        }
        
    }