<?php
     class Parties extends CI_Controller{
         public function __construct(){
            parent::__construct();
    
            $this->load->model('Universal_model','unicon');
            sessionCheck();
         }

         // Country

        public function vendorAdd(){
            $userCon = sessionUserData();
            header('Content-Type: application/json');

            // ID`, `V_NAME`, ``, ``, ``, `V_EMAIL`, ``, `COMPANY_NAME`, `COMPANY_CONTACT`, `COMPANY_EMAIL`, `BANK_AC`, `BANK_NO`, `IBAN`, `FULL_ADDRESS`, `BUILDING_NO`, `STREET`, `ADDITIONAL_NO`, `OTHER_SELLER_ID`, `COUNTRY`, `POSTAL_CODE`, `VAT_NO`, `UNIT_NO`, `OPENING_BAL`, `CREDIT_LIMIT`, `WALLET`, `ADD_BY`, `C_DATE`

            $contryId = $this->input->post('V_CODE');
            $vc_email = $this->input->post('COMPANY_EMAIL');
            $vc_contact = $this->input->post('COMPANY_CONTACT');
            if($contryId){
                $this->form_validation->set_rules('V_CODE', 'unique code', 'unique_code_db[VENDOR.V_CODE.Vendor Code already used, Please choose a different one]');
            }
            if($vc_email){
                $this->form_validation->set_rules('COMPANY_EMAIL', 'unique code', 'unique_code_db[VENDOR.COMPANY_EMAIL.Company email already used, Please choose a different one]');
            }
            if($vc_contact){
                $this->form_validation->set_rules('COMPANY_CONTACT', 'unique code', 'unique_code_db[VENDOR.COMPANY_CONTACT.Company contact already used, Please choose a different one]');
            }
            $this->form_validation->set_rules('V_NAME', 'Vendor Name', 'required|alpha_space');
            $this->form_validation->set_rules('V_NAME_AR', 'Vendor Name Arabic', 'required');
            $this->form_validation->set_rules('V_CONTACT', 'Contact no', 'required|numeric');
            $this->form_validation->set_rules('country_name', 'Country name', 'required');
            $this->form_validation->set_rules('state_name', 'State name', 'required');
            $this->form_validation->set_rules('city_name', 'City name', 'required');
            $this->form_validation->set_rules('V_POSTAL_CODE_ID', 'Postal code', 'required');


            if($this->form_validation->run() === FALSE){
                $omsg = $this->form_validation->error_array();
                echo json_encode(array("multi"=>"true","err"=>"true","msg"=>$omsg));
            }else{
                
                $data = array(
                    
                            "V_CODE"=>empty($contryId)?insertUniqueCode('V_CODE'):$contryId,
                            "V_NAME"=>$this->input->post('V_NAME'),
                            "V_NAME_AR"=>$this->input->post('V_NAME_AR'),
                            "V_CONTACT"=>$this->input->post('V_CONTACT'),
                            "V_EMAIL"=>$this->input->post('V_EMAIL'),
                            "V_POSTAL_CODE"=>$this->input->post('V_POSTAL_CODE_ID'),
                            "CITY_ID"=>$this->input->post('city_name'),
                            "COMPANY_NAME"=>empty($this->input->post('COMPANY_NAME'))?NULL:$this->input->post('COMPANY_NAME'),
                            "COMPANY_CONTACT"=>empty($this->input->post('COMPANY_CONTACT'))?NULL:$this->input->post('COMPANY_CONTACT'),
                            "COMPANY_EMAIL"=>empty($this->input->post('COMPANY_EMAIL'))?NULL:$this->input->post('COMPANY_EMAIL'),
                            "VAT_NO"=>empty($this->input->post('VAT_NO'))?NULL:$this->input->post('VAT_NO'),
                            "UNIT_NO"=>empty($this->input->post('UNIT_NO'))?NULL:$this->input->post('UNIT_NO'),
                            // "OPENING_BAL"=>empty($this->input->post('OPENING_BAL'))?'0':$this->input->post('OPENING_BAL'),
                            // "CREDIT_LIMIT"=>empty($this->input->post('CREDIT_LIMIT'))?'0':$this->input->post('CREDIT_LIMIT'),
                            "BANK_AC"=>empty($this->input->post('BANK_AC'))?NULL:$this->input->post('BANK_AC'),
                            "BANK_NO"=>empty($this->input->post('BANK_NO'))?NULL:$this->input->post('BANK_NO'),
                            "IBAN"=>empty($this->input->post('IBAN'))?NULL:$this->input->post('IBAN'),
                            "FULL_ADDRESS"=>empty($this->input->post('FULL_ADDRESS'))?NULL:$this->input->post('FULL_ADDRESS'),
                            "BUILDING_NO"=>empty($this->input->post('BUILDING_NO'))?NULL:$this->input->post('BUILDING_NO'),
                            "STREET"=>empty($this->input->post('STREET'))?NULL:$this->input->post('STREET'),
                            "ADDITIONAL_NO"=>empty($this->input->post('ADDITIONAL_NO'))?NULL:$this->input->post('ADDITIONAL_NO'),
                            "V_CRE_BY"=>$userCon->ID,
                        );
                if($this->unicon->insertUniversal('VENDOR',$data)){
                
                echo json_encode(array("multi"=>"false","err"=>"false","msg"=>"Data Inserted Successfully"));
              
                
                }else{

                echo json_encode(array("multi"=>"false","err"=>"true","msg"=>"something went wrong"));

                }
            }
        }

        public function vendorListJson(){
            $filterdata = array(
                "column_order" => array(NULL,'V_CODE'.'V_NAME','V_CONTACT',NULL,NULL),
                "column_search" => array('V_CODE'.'V_NAME','V_CONTACT'),
                "order" => array('ID' => 'desc')
            );
            $sqlQueryTemp = array(

                "SELECT"=>'*',
                "FROM"=>'VENDOR',

                "JOIN_1_CONTROL"=>FALSE,  // TABLE JOINING CONTROL TRUE ENABLE AND FALSE DISABLE DEFAULT VALUE FALSE
                    "JOIN_1_TABLE_NAME"=>'CURRENCY as CR',
                    "JOIN_1_TABLE_CONN"=>'CR.CUR_ID=CT.CNTRY_CURRENCY',
            );

            $sqlQuery = datatableSqlData($sqlQueryTemp);

            $memData = $this->datatableCon->getRows($_POST,$sqlQuery,$filterdata);

            $ttype = $this->input->post('saletype')=="invoice"?'saleinvoice':'saleorder';
        
            $data = array();
            $no = $this->input->post('start');
            foreach ($memData as $rowdata) {
                $no++; $row = array();
                $row[] = $no.".";
                // $row[] = "<a href= '".base_url('stockTransfer/stockAdjustmentDetail/').$rowdata->INVOICE_NO."'>$rowdata->INVOICE_NO</a>";
                // $row[] = $rowdata->TOT_QTY;
                // $row[] ="<div class='badge badge-success' bis_skin_checked='1'> <i class='fa fa-inr' aria-hidden='true' title='Full View'></i>".$rowdata->GRAND_TOT."</div>";
                // $row[] = "<strong>".$rowdata->REASON."</strong>";
                $row[] = $rowdata->V_CODE;
                $row[] = $rowdata->V_NAME;
                $row[] = $rowdata->V_CONTACT;
                $row[] = $rowdata->V_POSTAL_CODE_ID;
                $row[] = '0';
                $row[] = "<ul class='list-unstyled hstack gap-1 mb-0'>
                            <li data-bs-toggle='tooltip' data-bs-placement='top' title='Edit'>
                                <a href='#' class='btn btn-sm btn-soft-info'><i class='mdi mdi-pencil-outline'></i></a>
                            </li>
                        </ul>";
                //$editSt = $rowdata->STATUS != 'COMPLETE'?"<a href= '".base_url('stockTransfer/stockTransferEdit/').$rowdata->INVOICE_NO."' title='Edit' class='btn-danger btn btn-primary' ><i class='fa fa-edit' > </i></a>":'';
                // $row[] ="
                //         <div role='group' class='btn-group-sm btn-group'>
                //         <a href= '".base_url('stockTransfer/stockAdjustmentDetail/').$rowdata->INVOICE_NO."' target='_blank' title='Full View' class='btn-shadow btn btn-primary' ><i class='fa fa-eye' aria-hidden='true' ></i></a>
                //         <a href= '".base_url('stockTransfer/stockAdjustmentDetail/').$rowdata->INVOICE_NO."' title='Print' target='_blank' class='btn-info btn btn-primary' ><i class='lnr-printer  opacity-0 btn-icon-wrapper mb-2' > </i></a>
                //         </div>";
                $data[] = $row;
            }
            $output = array(
                "draw" => empty($this->input->post('draw')) ? 'none' : $this->input->post('draw'),
                "recordsTotal" => $this->datatableCon->countAll($sqlQuery),
                "recordsFiltered" => $this->datatableCon->countFiltered($_POST,$sqlQuery),
                "data" => $data
            );
            //output to json format
            header('Content-Type: application/json');
            echo json_encode($output);
        }

    }

?>