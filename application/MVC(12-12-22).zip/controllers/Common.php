<?php
     class Common extends CI_Controller{
         public function __construct(){
            parent::__construct();
      
            // $this->load->model('Site_model', 'dbcon');
            $this->load->model('Universal_model','unicon');
            // $this->load->library('form_validation');
            // $this->load->helper('form');
            //$this->load->model('QrController','qrcon');
         }

        public function getStateByCntryCode(){
            $cntryCode = $this->input->post('country_code');
            $data = $this->unicon->CoreQuery("SELECT * FROM STATES WHERE ST_CNTRY_ID='$cntryCode'","result_array");
            echo json_encode($data);
        }

        public function getCItyByStCode(){
            $stateCode = $this->input->post('state_code');
            $data = $this->unicon->CoreQuery("SELECT * FROM CITIES WHERE CTY_STATE_CODE='$stateCode'","result_array");
            echo json_encode($data);
        }

        public function getClassDescbyCode(){
            $classCode = $this->input->post('class_code');
            $data = $this->unicon->CoreQuery("SELECT * FROM ITEM_CLASSES WHERE IC_CODE='$classCode'","result_array");
            echo json_encode($data);
        }

        public function getCatDescbyCode(){
            $catCode = $this->input->post('cat_code');
            $data = $this->unicon->CoreQuery("SELECT * FROM ITEM_CATEGORY WHERE ICAT_CODE='$catCode'","result_array");
            echo json_encode($data);
        }

        public function getCntryDescbyCode(){
            $cntryCode = $this->input->post('cntry_code');
            $data = $this->unicon->CoreQuery("SELECT * FROM COUNTRIES WHERE CNTRY_CODE='$cntryCode'","result_array");
            echo json_encode($data);
        }

        public function getClassListByCategoryCode(){
            $catCode = $this->input->post('cat_code');
            $data = $this->unicon->CoreQuery("SELECT * FROM ITEM_CLASSES WHERE IC_ITEM_CAT='$catCode'","result_array");
            echo json_encode($data);
        }

        public function getTraitListbyCode(){
            $catCode = $this->input->post('cat_code');

            $catDesc = $this->unicon->CoreQuery("SELECT * FROM TRAIT_CATEGORY WHERE TC_CODE='$catCode'","result_array");
            $data = $this->unicon->CoreQuery("SELECT * FROM TRAIT_SUB_CATEGORY WHERE TRAIT_CAT_ID='$catCode'","result_array");

            echo json_encode(['trait_data'=>$data,'cat_desc'=>count($catDesc)==1?$catDesc[0]['TC_DESC']:'Data not Available']);
        }

        public function getItemTraitByItemCode(){
            $itemCode = $this->input->post('itemCode');

            $itemDel = $this->unicon->CoreQuery("SELECT * FROM ITEMS WHERE I_CODE='$itemCode'","result_array");

            $data = $this->unicon->CoreQuery("SELECT * FROM ITEMS as I
                                                        JOIN ITEM_TRAITS AS IT
                                                        ON IT.ITM_CODE =I.I_CODE
                                                        JOIN TRAIT_CATEGORY AS TC
                                                        ON TC.TC_CODE = IT.ITM_TRAIT_CAT_CODE
                                                        JOIN TRAIT_SUB_CATEGORY AS TSC
                                                        ON TSC.TRAIT_SUB_CAT_CODE =IT.ITM_TRAIT_CODE AND TSC.TRAIT_CAT_ID =IT.ITM_TRAIT_CAT_CODE
                                                        WHERE I.I_CODE='$itemCode'","result_array");

            echo json_encode(['traitDeaits'=>$data,'itemdel'=>count($itemDel)==1?$itemDel:NULL]);
        }

        public function getVenDelByVenCode(){
            $venCode = $this->input->post('ven_code');
            $data = $this->unicon->CoreQuery("SELECT * FROM VENDOR WHERE V_CODE LIKE '$venCode%'","row_array");
            echo json_encode(['ven_det'=>$data]);
        }

        public function getFreightDelByfreightCode(){
            $frtCode = $this->input->post('freight_code');
            $data = $this->unicon->CoreQuery("SELECT * FROM FREIGHTS WHERE FRT_CODE LIKE '$frtCode%'","row_array");
            echo json_encode(['freight_det'=>$data]);
        }

        public function getTermdetBytermCode(){
            $termCode = $this->input->post('term_code');
            $data = $this->unicon->CoreQuery("SELECT * FROM TERMS WHERE TERM_CODE LIKE '$termCode%'","row_array");
            echo json_encode(['term_det'=>$data]);
        }

        public function getFobdetByFobCode(){
            $fobCode = $this->input->post('fob_code');
            $data = $this->unicon->CoreQuery("SELECT * FROM FOBS WHERE FOB_CODE LIKE '$fobCode%'","row_array");
            echo json_encode(['fob_det'=>$data]);
        }

        public function getShipDetByShipCode(){
            $shipCode = $this->input->post('ship_code');
            $data = $this->unicon->CoreQuery("SELECT * FROM SHIP_VIA WHERE SHIPV_CODE LIKE '$shipCode%'","row_array");
            echo json_encode(['ship_det'=>$data]);
        }

        public function getPOChargeByPoCode(){
            $poChargeType = $this->input->post('po_charge_type');
            $data = $this->unicon->CoreQuery("SELECT * FROM PO_CHARGES WHERE CHRG_TYPE LIKE '$poChargeType%'","row_array");
            echo json_encode(['po_charge_det'=>$data]);
        }

        public function getCurExhRateByCurCode(){
            $curCodeNdName = $this->input->post('cur_exh_code');
            $data = $this->unicon->CoreQuery("SELECT *
                                                FROM CURRENCY
                                                JOIN CURRENCY_EXCHANGE_RATE
                                                ON CURRENCY_EXCHANGE_RATE.EXCHR_CURRENCY = CURRENCY.CUR_CODE
                                                WHERE CURRENCY.CUR_CODE LIKE '%$curCodeNdName%' 
                                                OR
                                                CURRENCY.CUR_NAME LIKE '%$curCodeNdName%'
                                                ORDER BY CURRENCY_EXCHANGE_RATE.EXCHR_CRE_DATE DESC
                                                LIMIT 1","row_array");
            echo json_encode(['cur_exh_det'=>$data]);
        }

        public function getitemDetByItemCode(){
            $itemCode = $this->input->post('item_code');
            $venCode = $this->input->post('v_code');
            $data = itemDetails($itemCode,1,$venCode);
            echo json_encode(['item_det'=>$data]);
        }

        public function getPoPrefix(){
          
            $data = poPrefixes();
            echo json_encode($data);
        }



        // public function getTraitByItemCode(){
        //     $itemCode = $this->input->post('itemCode');

        //     $itemDel = $this->unicon->CoreQuery("SELECT * FROM ITEMS WHERE I_CODE='$itemCode'","result_array");

        //     $data = $this->unicon->CoreQuery("SELECT * FROM ITEMS as I
        //                                                 JOIN ITEM_TRAITS AS IT
        //                                                 WHERE I.I_CODE='$itemCode'","result_array");

        //     echo json_encode(['traitDeaits'=>$data,'itemdel'=>count($itemDel)==1?$itemDel:NULL]);
        // }
    }