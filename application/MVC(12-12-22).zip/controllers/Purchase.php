<?php
     class Purchase extends CI_Controller{
         public function __construct(){
            parent::__construct();
            $this->load->model('Universal_model','unicon');
        }

        public function purchaseAdddb(){
            $userCon = sessionUserData();
            header('Content-Type: application/json');
            
            $this->form_validation->set_rules('POH_VENDOR_CODE', 'vendor code/name', 'required');
            $this->form_validation->set_rules('POH_SHIP_VIA_CODE', 'ship via', 'required');
            $this->form_validation->set_rules('POH_FREIGHT_CODE', 'freight', 'required');
            $this->form_validation->set_rules('POH_TERMS_CODE', 'Sterm', 'required');
            $this->form_validation->set_rules('POH_FOB_CODE', 'fob', 'required');
            // $this->form_validation->set_rules('saledate', 'Saleorder Date', 'required');
            // if($usertype=="mechanic"){ $this->form_validation->set_rules('delboyid', 'Delivery Boy', 'required'); }
            if($this->form_validation->run() === FALSE){
                $omsg = $this->form_validation->error_array();
                echo json_encode(array("multi"=>"true","err"=>"true","msg"=>$omsg));
            }else{

                $temp_order_id = random_strings(10,'AN');

                // PO HEADER
                    $data = [
                        "POH_ORDER_ID"=>$temp_order_id,
                        "POH_ORDER_DATE"=>$this->input->post('POH_ORDER_DATE'),
                        "POH_CLASS"=>$this->input->post('POH_CLASS'),
                        "POH_REF_NO_1"=>$this->input->post('POH_REF_NO_1'),
                        "POH_REF_NO_2"=>$this->input->post('POH_REF_NO_2'),
                        "POH_STATUS"=>$this->input->post('POH_STATUS'),
                        "POH_HOLD_FLAG"=>empty($this->input->post('POH_HOLD_FLAG'))?'0':$this->input->post('POH_HOLD_FLAG'),
                        "POH_SHIP_VIA_CODE"=>$this->input->post('POH_SHIP_VIA_CODE'),
                        "POH_FREIGHT_CODE"=>$this->input->post('POH_FREIGHT_CODE'),
                        "POH_TERMS_CODE"=>$this->input->post('POH_TERMS_CODE'),
                        "POH_FOB_CODE"=>$this->input->post('POH_FOB_CODE'),
                        "POH_CUR_EXCH_ID"=>$this->input->post('POH_CUR_EXCH_ID'),
                        "POH_CRE_BY"=>$userCon->ID,
                    ];

                // PO DETAIL
                    $itemCode = $this->input->post('POD_ITEM_CODE');
                    $itemQty = $this->input->post('POD_ITEM_QTY');
                    $itemPrice = $this->input->post('POD_ITEM_PRICE');
                    for ($i=0; $i <count($itemCode) ; $i++) { 
                        $getItemRow = $this->unicon->CoreQuery("SELECT * FROM ITEMS WHERE VEN_CODE='{$data['POH_VENDOR_CODE']}' AND I_CODE ='$itemCode'","num_rows");
                        if($getItemRow>0){
                            
                        }
                    }

                if($this->unicon->insertUniversal('PO_HEADER',$data)){
                    
                    $purOrderType = $this->input->post('pur_order_type_db');
                        $preFix = $this->unicon->CoreQuery("SELECT * FROM PO_PREFIXES WHERE POP_ORDER_PFX ='$purOrderType'","row");
                        $this->unicon->CoreQuery("UPDATE PO_HEADER SET POH_ORDER_ID='{$preFix->POP_NEXT_NUMBER}' WHERE POH_ORDER_ID='$temp_order_id'");

                echo json_encode(array("multi"=>"false","err"=>"false","msg"=>"Data Inserted Successfully"));
              
                
                }else{

                echo json_encode(array("multi"=>"false","err"=>"true","msg"=>"something went wrong"));

                }
            }
        }
         
    }