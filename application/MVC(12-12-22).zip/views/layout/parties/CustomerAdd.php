
<!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">ADD Customer</h4>
                                    <div class="page-title-right">
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                        

                       
                        <div class="row">
                            <div class="col-xl-12">
                                <div class="card"> 
                                    <div class="card-body border-bottom">
                                            <div class="d-flex align-items-center">
                                                <h5 class="mb-0 card-title flex-grow-1">Add New Customer</h5>
                                                <div class="flex-shrink-0">
                                                    <a href="<?=base_Url()?>CustomerList" class="btn btn-primary" >Customer List</a>
                                                    <a href="#!" class="btn btn-light"><i class="mdi mdi-refresh"></i></a>
                                                </div>
                                               
                                            </div>
                                        </div>
                                    <div class="card-body">
                                            <form id="formdata">
                                                <div class="row">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom03" class="form-label">Code</label>
                                                                    <input type="text" class="form-control" name="contry_name" placeholder="Code ">
                                                                    <label id="contry_name-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom03" class="form-label">Customer Group</label>
                                                                    <input type="text" class="form-control" name="contry_name" placeholder="Customer Group ">
                                                                    <label id="contry_name-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Customer Name</label>
                                                                <input type="email" class="form-control" name="CUST_NAME" placeholder="Customer Name">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Customer Type</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Customer Type">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Customer Name in Arabic</label>
                                                                <input type="email" class="form-control" name="CUST_NAME_AR" placeholder="Customer Name in Arabic">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Territory</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Territory">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        
                                                         <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Account Manager</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Account Manager">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Default Company Bank Account</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Enter Customer">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Tax ID</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Tax ID">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Tax Withholding Category</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Tax Withholding Category">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Address</h4>
                                    <div class="page-title-right">
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                                                          <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Address Line 1</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Address Line 1">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Address Line 2</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Address Line 2">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Address Line 3</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Address Line 3">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">State</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="State">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Country</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Country">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">City</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="City">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Fax 1</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Fax 1">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Fax 2</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Fax 2">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Phone no 1</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Phone no 1">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Phone No 2</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Phone No 2">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Pincode</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Tax Withholding Category">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Pincode</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Tax Withholding Category">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Email 1</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Email 1">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">More</h4>
                                    <div class="page-title-right">
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">EDI1</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="EDI1">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">EDI2</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="EDI2">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Default Price List</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Default Price List">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Card</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Card">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Branch</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Branch">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">TAX EXEMPT ID</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="TAX EXEMPT ID">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">ENGLISH SALUTATION</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="ENGLISH SALUTATION">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">TAX AUTHORITY</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="TAX AUTHORITY">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Notes</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Notes">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">ARABIC SALUTATION</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="ARABIC SALUTATION">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Billing Currency</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Billing Currency">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Primary Address and Contact Detail</h4>
                                    <div class="page-title-right">
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                                                     <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Customer Primary Contact</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Customer Primary Contact">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Customer Primary Address</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Customer Primary Address">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                         <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Default Receivable Accounts </h4>
                                    <div class="page-title-right">
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                         <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Credit Limit and Payment Terms</h4>
                                    <div class="page-title-right">
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                         <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">More Information</h4>
                                    <div class="page-title-right">
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                                                         <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Customer Details</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Customer Details">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Market Segment</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Market Segment">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Industry</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Industry">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Website</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="Website">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="validationCustom04" class="form-label">Print Language</label>
                                                                <input type="email" class="form-control" name="contry_abbra" placeholder="English">
                                                                <label id="contry_abbra-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        
                                                       
                                                        
                                                        
                                                        
                                                        
                                                    
                                                    
                                                        
                                                        
                                                    </div>
                                                <div>
                                                    <button data-control="master/country-add" data-form="formdata" class="ajaxform btn btn-success waves-effect waves-light" type="submit">Add Customer</button>
                                                </div>
                                                <span id="outmsg"></span>
                                            
                                        </div>
                                        </form>
                                    </div>
                                    <!-- end card -->
                                </div> 
                             </div>
                        </div>
                
                
                       
                
                <!-- End Page-content -->
                
                    </div>
                </div>
                    
                <!-- Modal -->
                <div class="modal fade" id="jobDelete" tabindex="-1" aria-labelledby="jobDeleteLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-sm">
                        <div class="modal-content">
                            <div class="modal-body px-4 py-5 text-center">
                                <button type="button" class="btn-close position-absolute end-0 top-0 m-3" data-bs-dismiss="modal" aria-label="Close"></button>
                                <div class="avatar-sm mb-4 mx-auto">
                                    <div class="avatar-title bg-primary text-primary bg-opacity-10 font-size-20 rounded-3">
                                        <i class="mdi mdi-trash-can-outline"></i>
                                    </div>
                                </div>
                                <p class="text-muted font-size-16 mb-4">Are you sure you want to permanently erase the job.</p>
                                
                                <div class="hstack gap-2 justify-content-center mb-0">
                                    <button type="button" class="btn btn-danger">Delete Now</button>
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <!-- end main content-->
            <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script>
   
    $(document).ready(function() {
        $('#datatable').DataTable({

            "processing": true,

            "serverSide": true,

            "lengthMenu": [[10, 25, 50,100, -1], [10, 25, 50,100, "All"]],

            "dom" : 'lBfrtip',

            "buttons" : ['copy', 'csv', 'excel', 'print'],

            "order": [],

            "scrollX": true,

            "ajax": { "url": "<?=base_url('master/country-table-list'); ?>", "type": "POST","data":{device:"web"} }

        });

    });
</script>
        