
<!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Price Change Order</h4>
                                    <div class="page-title-right">
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                        
                        
                        <div class="row">
                            <div class="col-xl-12">
                                <div class="card"> 
                                    <div class="card-body border-bottom">
                                            <div class="d-flex align-items-center">
                                                <h5 class="mb-0 card-title flex-grow-1">Price Change Order</h5>
                                               
                                            <!--<div class="flex-shrink-0">-->
                                            <!--    <a href="<?=base_Url()?>InventoryList" class="btn btn-primary" >View Inventory List</a>-->
                                            <!--    <a href="#!" class="btn btn-light"><i class="mdi mdi-refresh"></i></a>-->
                                            <!--</div>-->
                                            
                                            </div>
                                        </div>
                                    <div class="card-body">
                                            <form id="formdata">
                                                <div class="row">
                                                    <div class="row">
                                                         
                                                        <div class="col-md-3">
                                                            <div class="mb-3">
                                                                <label for="validationCustom03" class="form-label">Document Number</label>
                                                                    <input type="text" class="form-control" name="V_CODE" placeholder="Enter Number">
                                                                    <label id="V_CODE-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                         <div class="col-md-2">
                                                            <div class="mb-3">
                                                                <label for="validationCustom03" class="form-label">Document Date</label>
                                                                    	<input class="form-control" type="date" name="item_rev_date" value="2022-11-30">
                                                                    <label id="V_NAME-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="col-md-3">
                                                            <div class="mb-3">
                                                                
                                                                <label for="validationCustom03" class="form-label">Refrence</label>
                                                                    <input type="text" class="form-control" name="V_NAME_AR" >
                                                                    <label id="V_NAME_AR-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                        <div class="col-md-2">
                                                            <div class="mb-3">
                                                                <label for="validationCustom03" class="form-label">Type </label>
                                                                    <input type="text" class="form-control" name="V_CODE" placeholder="Type ">
                                                                    <label id="V_CODE-error" class="error"></label>
                                                            </div>
                                                            
                                                        </div>
                                                        <div class="col-md-2">
                                                            <label for="validationCustom03" class="form-label">Report And Post</label>
                                                             <div class="hstack gap-2  mb-0">
                                                                    <button type="button" class="btn btn-primary">Report</button></br>
                                                                         <button type="button" class="btn btn-primary" >Post</button>
                                                                </div>
                                                            
                                                        </div>
                                                        
                                                        <div class="col-md-5">
                                                            <div class="mb-3">
                                                                <label for="validationCustom03" class="form-label">Remark</label>
                                                                    	<input class="form-control" type="text" name="Item Class">
                                                                    <label id="V_NAME-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="col-md-2">
                                                            <div class="mb-3">
                                                                
                                                                <label for="validationCustom03" class="form-label">Warehouse</label>
                                                                    <input type="text" class="form-control" name="Item Desc" >
                                                                    <label id="V_NAME_AR-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="col-md-2">
                                                            <div class="mb-3">
                                                                
                                                                <label for="validationCustom03" class="form-label">posted</label>
                                                                    <input type="text" class="form-control" name="Item Desc" >
                                                                    <label id="V_NAME_AR-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                        
                                                        
                                                        <div class="col-md-3">
                                                            <label for="validationCustom03" class="form-label">For Authenticate</label>
                                                             <div class="hstack gap-2  mb-0">
                                                                 <button type="button" class="btn btn-primary">Authenticate</button>
                                                                     <!--<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>-->
                                                             </div>
                                                        </div>
                                                        
                                                       <div class="col-md-3">
                                                           <div class="mb-3">
                                                                
                                                                <label for="validationCustom03" class="form-label">Price Change %</label>
                                                                    <select class="form-select" name="item_status">
                                                                        <option value="0">0</option>
                                                                        <option value="5">5</option>
                                                                        <option value="10">10</option>
                                                                         <option value="15">15</option>
                                                                        <option value="20">20</option>
                                                                         <option value="25">25</option>
                                                                        <option value="30">30</option>
                                                                    </select>
                                                                    <label id="V_NAME_AR-error" class="error"></label>
                                                  </div>
                                                        </div>
                                                        
                                                        <div class="col-md-4">
                                                            <label for="validationCustom03" class="form-label">Apply or Revert Changes</label>
                                                             <div class="hstack gap-2  mb-0">
                                                                 <button type="button" class="btn btn-primary">Apply Change</button>
                                                                    <button type="button" class="btn btn-primary">Revert Change</button>
                                                                 </div>
                                                        </div>
                                                        
                                                        <div class="col-md-2">
                                                            <div class="mb-3">
                                                                
                                                                <label for="validationCustom03" class="form-label">Promotion Code</label>
                                                                    <input type="text" class="form-control" name="V_NAME_AR" >
                                                                    <label id="V_NAME_AR-error" class="error"></label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <label for="validationCustom03" class="form-label">Add to Promotion</label>
                                                             <div class="hstack gap-2  mb-0">
                                                                 <button type="button" class="btn btn-primary">Add to Promotion</button>
                                                                    <!--<button type="button" class="btn btn-secondary">Revert Change</button>-->
                                                                 </div>
                                                        </div>
                                                        
                                                        
                                                     
                                                        
                                                        <h2 class="mb-3">Price Change Order</h2>
                                         <div class="table-responsive">
                                            <table class="table align-middle table-nowrap table-check">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th style="width: 20px;" class="align-middle">
                                                            
                                                        </th>
                                                        <th class="align-middle">Item</th>
                                                        <th class="align-middle">Vendor Code</th>
                                                        <th class="align-middle">Item Desc</th>
                                                        <th class="align-middle">Price</th>
                                                        <th class="align-middle">Markup</th>
                                                       
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            
                                                        </td>
                                                        <td><a class="text-body fw-bold">15</a> </td>
                                                        <td>01</td>
                                                        <td>
                                                            Weight
                                                        </td>
                                                        <td>
                                                            Gold
                                                        </td>
                                                        <td>
                                                            2.21
                                                        </td>
                                                        
                                                        
                                                       
                                                    </tr>

                                                   

                                                   
                                                    
                                                </tbody>
                                            </table>
                                        </div>
    						                         
                                        
    						                          
                                                        
                                                        
    						  
 
                            
                           
                                                    </div>
                                               
                                                <span id="outmsg"></span>
                                            
                                        </div>
                                        </form>
                                    </div>
                                    <!-- end card -->
                                    
                                    
                                </div> 
                             </div>
                        </div>
                        
                       
                
                
                
                <!-- End Page-content -->
                
                    </div>
                </div>
                    
                <!-- Modal -->
                <div class="modal fade" id="jobDelete" tabindex="-1" aria-labelledby="jobDeleteLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-sm">
                        <div class="modal-content">
                            <div class="modal-body px-4 py-5 text-center">
                                <button type="button" class="btn-close position-absolute end-0 top-0 m-3" data-bs-dismiss="modal" aria-label="Close"></button>
                                <div class="avatar-sm mb-4 mx-auto">
                                    <div class="avatar-title bg-primary text-primary bg-opacity-10 font-size-20 rounded-3">
                                        <i class="mdi mdi-trash-can-outline"></i>
                                    </div>
                                </div>
                                <p class="text-muted font-size-16 mb-4">Are you sure you want to permanently erase the job.</p>
                                
                                <div class="hstack gap-2 justify-content-center mb-0">
                                    <button type="button" class="btn btn-danger">Delete Now</button>
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <!-- end main content-->
            <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script>
   
    function classLists(ele) {
        $.ajax({
            type: "POST",
            url: "<?=base_url('Common/getClassDescbyCode')?>",
            data: {class_code:ele.value},
            dataType: "Json",
            success: function(resultData){
                if(resultData.length>0){
                    $('#class_desc_in').val(resultData[0]['IC_DESC']);
                }else{
                    $('#class_desc_in').val('');
                }
            }
        });
    }

    function catList(ele) {
        $.ajax({
            type: "POST",
            url: "<?=base_url('Common/getCatDescbyCode')?>",
            data: {cat_code:ele.value},
            dataType: "Json",
            success: function(resultData){
                if(resultData.length>0){
                    $('#cat_desc_in').val(resultData[0]['ICAT_DESC']);
                }else{
                    $('#cat_desc_in').val('');
                }
            }
        });
    }

</script>
        