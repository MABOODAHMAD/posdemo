
<!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Purchase</h4>
                                    <div class="page-title-right">
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                        
                        
                        <div class="row">
                            <div class="col-xl-10">
                                
                                
                                <div class="card">
                                    <div class="card-body">
                                        <div class="invoice-title">
                                            <h4 class="float-end font-size-16">Order # 12345</h4>
                                            <div class="mb-4">
                                                <img src="assets/images/logo-dark.png" alt="logo" height="40px">
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="row">
                                            <div class="col-sm-6 mt-3">
                                                <address>
                                                    <strong>Payment Method:</strong><br>
                                                    Visa ending **** 4242<br>
                                                    jsmith@email.com
                                                </address>
                                            </div>
                                            <div class="col-sm-6 mt-3 text-sm-end">
                                                <address>
                                                    <strong>Order Date:</strong><br>
                                                    October 16, 2019<br><br>
                                                </address>
                                            </div>
                                        </div>
                                        
                                        <div class="row">
                                            <!--<table width="100%" border="0" cellpadding="0" cellspacing="0">-->
  
                                            <div class="col-sm-6 mt-3">
                                                <address>
                                                    <strong>Billed To:</strong><br>
                                                    John Smith<br>
                                                    1234 Main<br>
                                                    Apt. 4B<br>
                                                    Springfield, ST 54321
                                                </address>
                                            </div>
    
                                            <div class="col-sm-6 mt-3 text-sm-end">
                                                <address>
                                                    <strong>Shipped To:</strong><br>
                                                    Kenny Rigdon<br>
                                                    1234 Main<br>
                                                    Apt. 4B<br>
                                                    Springfield, ST 54321
                                                </address>
                                            </div>
  
                                                </table>
                                            
                                            
                                        </div>
                                        
                                        <div class="py-2 mt-3">
                                            <h3 class="font-size-15 fw-bold">Order summary</h3>
                                        </div>
                                        <div class="table-responsive">
                                            <table class="table table-nowrap">
                                                <thead>
                                                    <tr>
                                                        <th style="width: 70px;">No.</th>
                                                        <th>Item</th>
                                                        <th class="text-end">Price</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>01</td>
                                                        <td>Skote - Admin Dashboard Template</td>
                                                        <td class="text-end">$499.00</td>
                                                    </tr>
                                                    
                                                    <tr>
                                                        <td>02</td>
                                                        <td>Skote - Landing Template</td>
                                                        <td class="text-end">$399.00</td>
                                                    </tr>

                                                    <tr>
                                                        <td>03</td>
                                                        <td>Veltrix - Admin Dashboard Template</td>
                                                        <td class="text-end">$499.00</td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="2" class="text-end">Sub Total</td>
                                                        <td class="text-end">$1397.00</td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="2" class="border-0 text-end">
                                                            <strong>Shipping</strong></td>
                                                        <td class="border-0 text-end">$13.00</td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="2" class="border-0 text-end">
                                                            <strong>Total</strong></td>
                                                        <td class="border-0 text-end"><h4 class="m-0">$1410.00</h4></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="d-print-none">
                                            <div class="float-end">
                                                <a href="javascript:window.print()" class="btn btn-success waves-effect waves-light me-1"><i class="fa fa-print"></i></a>
                                                <a href="javascript: void(0);" class="btn btn-primary w-md waves-effect waves-light">Send</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
        <!--                        <div class="card"> -->
        <!--                            <div class="card-body border-bottom">-->
        <!--                                    <div class="d-flex align-items-center">-->
        <!--                                        <h5 class="mb-0 card-title flex-grow-1">Add New Purchase</h5>-->
                                               
        <!--                                    <div class="flex-shrink-0">-->
        <!--                                        <a href="<?=base_Url()?>PurchaseList" class="btn btn-primary" >View Purchase List</a>-->
        <!--                                        <a href="#!" class="btn btn-light"><i class="mdi mdi-refresh"></i></a>-->
        <!--                                    </div>-->
                                            
        <!--                                    </div>-->
        <!--                                </div>-->
        <!--                            <div class="card-body">-->
        <!--                                    <form id="formdata">-->
        <!--                                        <div class="row">-->
        <!--                                            <div class="row">-->
                                                         
        <!--                                                <div class="col-md-4">-->
        <!--                                                    <div class="mb-3">-->
        <!--                                                        <label for="validationCustom03" class="form-label">Vendor Code / Name</label>-->
        <!--                                                            <input type="text" class="form-control" name="V_CODE" placeholder="Enter Items Code ">-->
        <!--                                                            <label id="V_CODE-error" class="error"></label>-->
        <!--                                                    </div>-->
        <!--                                                </div>-->
                                                        
        <!--                                                <div class="col-md-3">-->
        <!--                                                    <div class="mb-3">-->
        <!--                                                        <label for="validationCustom03" class="form-label">Purchase Order No</label>-->
        <!--                                                            	<input class="form-control" type="text" name="item_rev_date" placeholder="6587131">-->
        <!--                                                            <label id="V_NAME-error" class="error"></label>-->
        <!--                                                    </div>-->
        <!--                                                </div>-->
        <!--                                                 <div class="col-md-2">-->
        <!--                                                    <div class="mb-3">-->
        <!--                                                        <label for="validationCustom03" class="form-label">Order Date</label>-->
        <!--                                                            	<input class="form-control" type="date" name="item_rev_date" value="2022-11-30">-->
        <!--                                                            <label id="V_NAME-error" class="error"></label>-->
        <!--                                                    </div>-->
        <!--                                                </div>-->
                                                        
        <!--                                                <div class="col-md-3">-->
        <!--                                                    <div class="mb-3">-->
                                                                
        <!--                                                        <label for="validationCustom03" class="form-label">Class</label>-->
        <!--                                                            <input type="text" class="form-control" name="V_NAME_AR" >-->
        <!--                                                            <label id="V_NAME_AR-error" class="error"></label>-->
        <!--                                                    </div>-->
        <!--                                                </div>-->
                                                        
                                                        
        <!--                                                <div class="col-md-4">-->
                                                            
        <!--                                                </div>-->
                                                        
        <!--                                                <div class="col-md-3">-->
        <!--                                                    <div class="mb-3">-->
        <!--                                                        <label for="validationCustom03" class="form-label">Reference No</label>-->
        <!--                                                            	<input class="form-control" type="text" name="item_rev_date">-->
        <!--                                                            <label id="V_NAME-error" class="error"></label>-->
        <!--                                                    </div>-->
        <!--                                                </div>-->
                                                        
        <!--                                                <div class="col-md-2">-->
        <!--                                                    <div class="mb-3">-->
                                                                
        <!--                                                        <label for="validationCustom03" class="form-label">Reference No 2</label>-->
        <!--                                                            <input type="text" class="form-control" name="V_NAME_AR" >-->
        <!--                                                            <label id="V_NAME_AR-error" class="error"></label>-->
        <!--                                                    </div>-->
        <!--                                                </div>-->
                                                        
        <!--                                                <div class="col-md-2">-->
        <!--                                                    <div class="mb-3">-->
                                                                
        <!--                                                        <label for="validationCustom03" class="form-label">Status</label>-->
        <!--                                                            <select class="form-select" name="item_status">-->
        <!--                                                                <option value="1">Open</option>-->
        <!--                                                                <option value="0">Close</option>-->
        <!--                                                            </select>-->
        <!--                                                            <label id="V_NAME_AR-error" class="error"></label>-->
        <!--                                                    </div>-->
        <!--                                                </div>-->
                                                        
        <!--                                                <div class="col-md-1">-->
        <!--                                                    <div class="mb-3">-->
        <!--                                                        <label for="validationCustom03" class="form-label">&nbsp;</label>-->
        <!--                                                          <div class="form-check mb-3">-->
        <!--                                                    <input class="form-check-input" type="checkbox" id="formCheck1">-->
        <!--                                                    <label class="form-check-label" for="formCheck1">Hold Flag</label>-->
        <!--                                                </div>-->
        <!--                                                    </div>-->
        <!--                                                </div>-->
                                                        
                                                        
                                                        
                                                        
        <!--                                                <div class="col-md-4">-->
        <!--                                                    <div class="mb-3">-->
        <!--                                                        <label for="validationCustom03" class="form-label">Ship via</label>-->
        <!--                                                            	<input class="form-control" type="text" name="item_rev_date">-->
        <!--                                                            <label id="V_NAME-error" class="error"></label>-->
        <!--                                                    </div>-->
        <!--                                                </div>-->
                                                        
        <!--                                                <div class="col-md-3">-->
        <!--                                                    <div class="mb-3">-->
        <!--                                                        <label for="validationCustom03" class="form-label">Freight</label>-->
        <!--                                                            	<input class="form-control" type="text" name="item_rev_date">-->
        <!--                                                            <label id="V_NAME-error" class="error"></label>-->
        <!--                                                    </div>-->
        <!--                                                </div>-->
                                                        
        <!--                                                <div class="col-md-3">-->
        <!--                                                    <div class="mb-3">-->
                                                                
        <!--                                                        <label for="validationCustom03" class="form-label">Terms</label>-->
        <!--                                                            <input type="text" class="form-control" name="V_NAME_AR" >-->
        <!--                                                            <label id="V_NAME_AR-error" class="error"></label>-->
        <!--                                                    </div>-->
        <!--                                                </div>-->
                                                        
        <!--                                                <div class="col-md-2">-->
        <!--                                                    <div class="mb-3">-->
                                                                
        <!--                                                        <label for="validationCustom03" class="form-label">FOB</label>-->
        <!--                                                            <input type="text" class="form-control" name="V_NAME_AR" >-->
        <!--                                                            <label id="V_NAME_AR-error" class="error"></label>-->
        <!--                                                    </div>-->
        <!--                                                </div>-->
                                                        
                                                        
        <!--                                                  <div class="card-body border-bottom" style="margin-bottom: 20px;">-->
        <!--                                                    <div class="d-flex align-items-center">-->
        <!--                                                        <h5 class="mb-0 card-title flex-grow-1"><i class="mdi mdi-arrow-right text-primary"></i>Currency and Price List</h5>-->
        <!--                                                    </div>-->
        <!--                                                </div> -->
                                                        
                                                        
        <!--                                                <div class="col-md-6">-->
        <!--                                                	<div class="mb-3 row">-->
                                                        	    
                                                        	    
        <!--                                                    <div class="col-md-12">-->
        <!--                                                    <div class="mb-3">-->
        <!--                                                        <label for="validationCustom03" class="form-label">Currency</label>-->
        <!--                                                            	<input class="form-control" type="text" name="item_rev_date" placeholder="SAR">-->
        <!--                                                            <label id="V_NAME-error" class="error"></label>-->
        <!--                                                    </div>-->
        <!--                                                </div>-->
                                                        
        <!--                                                <div class="col-md-12">-->
        <!--                                                    <div class="mb-3">-->
        <!--                                                        <label for="validationCustom03" class="form-label">Exchange Rate</label>-->
        <!--                                                            	<input class="form-control" type="text" name="item_rev_date" placeholder="USD">-->
        <!--                                                            	<span class="text-muted">1 USD = [?] SAR</span>-->
        <!--                                                            <label id="V_NAME-error" class="error"></label>-->
        <!--                                                    </div>-->
        <!--                                                </div>-->
                                                        
        <!--                                                </div>-->
        <!--                                                </div>-->
                                                        
        <!--                                                <div class="col-md-6">-->
        <!--                                                	<div class="mb-3 row">-->
                                                        
        <!--                                                <div class="col-md-12">-->
        <!--                                                    <div class="mb-3">-->
                                                                
        <!--                                                        <label for="validationCustom03" class="form-label">Price List</label>-->
        <!--                                                            <input type="text" class="form-control" name="V_NAME_AR" placeholder="US$" >-->
        <!--                                                            <label id="V_NAME_AR-error" class="error"></label>-->
        <!--                                                    </div>-->
        <!--                                                </div>-->
                                                        
        <!--                                                <div class="col-md-12">-->
        <!--                                                    <div class="mb-3">-->
                                                                
        <!--                                                        <label for="validationCustom03" class="form-label">Price List Currency</label>-->
        <!--                                                            <input type="text" class="form-control" name="V_NAME_AR"  placeholder="USD">-->
        <!--                                                            <label id="V_NAME_AR-error" class="error"></label>-->
        <!--                                                    </div>-->
        <!--                                                </div>-->
        <!--                                                 <div class="col-md-8">-->
        <!--                                                    <div class="mb-3">-->
                                                                
        <!--                                                        <label for="validationCustom03" class="form-label">Price List Exchange Rate</label>-->
        <!--                                                            <input type="text" class="form-control" name="V_NAME_AR" placeholder="3.75">-->
        <!--                                                            <span class="text-muted">1 USD = [?] SAR</span>-->
        <!--                                                            <label id="V_NAME_AR-error" class="error"></label>-->
        <!--                                                    </div>-->
        <!--                                                    </div>-->
        <!--                                                   <div class="col-md-4"> -->
        <!--                                                    <div class="mb-3">-->
        <!--                                                        <label for="validationCustom03" class="form-label">&nbsp;</label>-->
        <!--                                                          <div class="form-check mb-3">-->
        <!--                                                    <input class="form-check-input" type="checkbox" id="formCheck1">-->
        <!--                                                    <label class="form-check-label" for="formCheck1">Ignore Pricing Rule</label>-->
        <!--                                                </div>-->
        <!--                                                    </div>-->
        <!--                                                </div>-->
        <!--                                                </div>-->
                                                        
        <!--                                                </div>-->
                                                        
        <!--                                                 <h5 class="font-size-14 card-body border-bottom"><i class="mdi mdi-arrow-right text-primary"></i> Item Line</h5>-->

                                                       
                                                       
        <!--                                               <div class="col-xl-12">-->
        <!--                        	<div class="form-row">-->
    				<!--		<div style="overflow-x:auto; overflow-y:hidden; /* white-space:nowrap; */ margin:0 10px;" class="ftable col-md-12">-->
    				<!--			<table id="productable" class="table table-hover table-striped table-bordered">-->
    				<!--				<thead>-->
    				<!--					<tr>-->
    				<!--						<th width="5%">Sn.</th>-->
								<!--			<th width="10%">Item No</th>-->
    				<!--						<th width="20%">Description</th>-->
    				<!--						<th width="15%">Qty</th>-->
    				<!--						<th width="20%">V Price</th>-->
    				<!--						<th width="5%">Exchange Rate</th>-->
    				<!--						<th width="10%">Distribution Amount</th>-->
    				<!--						<th width="100%">Unit Cost in SAR</th>-->
    				<!--						<th width="5%">Del.</th>-->
    				<!--					</tr>-->
    				<!--				</thead>-->
    				<!--				<tbody>-->
    				<!--					<tr>-->
    				<!--						<td width="5%">1</td>-->
    				<!--						<td width="10%">02288888</td>-->
    				<!--						<td width="20%">Ring</td>-->
    				<!--						<td width="15%"><input type="text" class="form-control" name="V_NAME_AR" value="1"></td>-->
    				<!--						<td width="20%"><input type="text" class="form-control" name="V_NAME_AR2" value="100" /></td>-->
    				<!--						<td width="5%"><span class="gqty" id="tknqty11">3.77</span> </td>-->
    				<!--						<td width="10%">1433.33 </td>-->
    				<!--						<td width="100%">1808.33</td>-->
    				<!--						<td width="10%"><i id="11" class="delete fa fa-trash"></i></td>-->
    				<!--					</tr>-->
								<!--		<tr>-->
    				<!--						<td width="5%">2</td>-->
    				<!--						<td width="10%">02277777</td>-->
    				<!--						<td width="20%">Bracelet</td>-->
    				<!--						<td width="15%"><input type="text" class="form-control" name="V_NAME_AR" value="1"></td>-->
    				<!--						<td width="20%"><input type="text" class="form-control" name="V_NAME_AR2" value="50" /></td>-->
    				<!--						<td width="5%"><span class="gqty" id="tknqty11">3.77</span> </td>-->
    				<!--						<td width="10%">1433.33 </td>-->
    				<!--						<td width="100%">1620.83</td>-->
    				<!--						<td width="10%"><i id="11" class="delete fa fa-trash"></i></td>-->
    				<!--					</tr>-->
								<!--		<tr>-->
    				<!--						<td width="5%">3</td>-->
    				<!--						<td width="10%">02277777</td>-->
    				<!--						<td width="20%">Bangle</td>-->
    				<!--						<td width="15%"><input type="text" class="form-control" name="V_NAME_AR" value="1"></td>-->
    				<!--						<td width="20%"><input type="text" class="form-control" name="V_NAME_AR2" value="25" /></td>-->
    				<!--						<td width="5%"><span class="gqty" id="tknqty11">3.77</span> </td>-->
    				<!--						<td width="10%">1433.33 </td>-->
    				<!--						<td width="100%">1527.08</td>-->
    				<!--						<td width="10%"><i id="11" class="delete fa fa-trash"></i></td>-->
    				<!--					</tr>-->
    				<!--				</tbody>-->
    				<!--			</table>-->

    				<!--		</div>-->
    						
    				<!--		</div> </div>-->
    				<!--		  <h5 class="font-size-14 card-body border-bottom"><i class="mdi mdi-arrow-right text-primary"></i> Extra Charges</h5>-->
    						  
        <!--						  <div class="col-md-6">-->
        						      
        <!--                            <div class="mb-3">-->
        <!--                            <label for="validationCustom03" class="form-label">FOB Charges</label>-->
        <!--                            </div>-->
                                           
        <!--                                    <table width="100%" border="0" cellpadding="0" cellspacing="0" class="table table-hover table-striped table-bordered">-->
        <!--<tr>-->
        <!--<td>&nbsp;</td>-->
        <!--<td>FOB</td>-->
        <!--<td>Amount</td>-->
        <!--<td>Amount ( SAR )</td>-->
        <!--<td>&nbsp;</td>-->
        <!--</tr>-->
        <!--<tr>-->
        <!--<td>&nbsp;</td>-->
        <!--<td>shipping</td>-->
        <!--<td>500</td>-->
        <!--<td>500</td>-->
        <!--<td>&nbsp;</td>-->
        <!--</tr>-->
        <!--</table>-->
        
        <!--<div class="col-md-8">-->
        <!--                                                        <div class="mb-3">-->
                                                                    
        <!--                                                            <label for="validationCustom03" class="form-label">Total FOB Charges</label>-->
        <!--                                                                <input type="text" class="form-control" name="V_NAME_AR" placeholder="500.00">-->
                                                                        
        <!--                                                                <label id="V_NAME_AR-error" class="error"></label>-->
        <!--                                                        </div>-->
        <!--                                                        </div>-->
        <!--                                </div>-->
                                        
        <!--                          <div class="col-md-6">-->
        <!--                                    <div class="mb-3">-->
        <!--                            <label for="validationCustom03" class="form-label">Extra Charges</label>-->
        <!--                            </div>-->
        <!--                                   <table width="100%" border="0" cellpadding="0" cellspacing="0" class="table table-hover table-striped table-bordered">-->
        <!--<tr>-->
        <!--<td>&nbsp;</td>-->
        <!--<td>Purchase Charges</td>-->
        <!--<td>Amount</td>-->
        
        <!--<td>&nbsp;</td>-->
        <!--</tr>-->
        <!--<tr>-->
        <!--<td>&nbsp;</td>-->
        <!--<td>Freight and Forwarding Charges</td>-->
        <!--<td>400.00</td>-->
        
        <!--<td>&nbsp;</td>-->
        <!--</tr>-->
        <!--</table>-->
        
        <!--<div class="col-md-8">-->
        <!--                                                        <div class="mb-3">-->
                                                                    
        <!--                                                            <label for="validationCustom03" class="form-label">Total Extra Charges</label>-->
        <!--                                                                <input type="text" class="form-control" name="V_NAME_AR" placeholder="400.00">-->
                                                                        
        <!--                                                                <label id="V_NAME_AR-error" class="error"></label>-->
        <!--                                                        </div>-->
        <!--                                                        </div>-->
        <!--                                </div>-->
                                                            
                                                        
                                    
        <!--                        <div class="col-xl-12">                        	    -->
                                                        	    
    				<!--		<div class="col-md-12">-->
    				<!--			<table width="100%" class="table table-bordered" >-->
    				<!--				<tbody>-->
    									
    				<!--					<tr>-->
    				<!--						<td width="70%" align="right"><b>Total Qty:</b> </td>-->
    				<!--						<td width="30%" align="left"><span id="gqty">3</span></td>-->
    				<!--					</tr>-->
    				<!--					<tr>-->
    				<!--						<td width="70%" align="right"><b>Subtol:</b> </td>-->
    				<!--						<td width="30%" align="left">SAR <span id="gsubtol">131.00</span></td>-->
    				<!--					</tr>-->
    									<!-- strt -->
    				<!--					<tr>-->
    				<!--						<td width="70%" align="right"><b>Total Tax:</b> </td>-->
    				<!--						<input type="hidden" name="gtoltax" id="gtoltaxid" value="217.65">-->
    				<!--						<td width="30%" align="left">SAR <span id="gtoltax">217.65</span></td>-->
    				<!--					</tr>-->
    									<!-- end -->
    									<!-- <tr style="display:none;"> -->
    				<!--					<tr>-->
    				<!--						<td width="70%" align="right"><b>Grand Total:</b> </td>-->
    				<!--						<td width="30%" align="left" style="    font-size: 0.8cm;    font-weight: bold;">SAR <span id="gtol">348.65</span> </td>-->
    				<!--					</tr>-->
    				<!--				</tbody>-->
    				<!--			</table>-->
    				<!--		</div>-->
    				<!--	</div>-->
                            
                           
        <!--                                            </div>-->
        <!--                                        <div>-->
        <!--                                            <button data-control="parties/vendor-add" data-form="formdata" class="ajaxform btn btn-success waves-effect waves-light" type="submit">Add Purchase</button>-->
        <!--                                        </div>-->
        <!--                                        <span id="outmsg"></span>-->
                                            
        <!--                                </div>-->
        <!--                                </form>-->
        <!--                            </div>-->
                                    <!-- end card -->
                                    
                                    
        <!--                        </div> -->
                             </div>
                        </div>
                        
                       
                
                
                
                <!-- End Page-content -->
                
                    </div>
                </div>
                    
                <!-- Modal -->
                <div class="modal fade" id="jobDelete" tabindex="-1" aria-labelledby="jobDeleteLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-sm">
                        <div class="modal-content">
                            <div class="modal-body px-4 py-5 text-center">
                                <button type="button" class="btn-close position-absolute end-0 top-0 m-3" data-bs-dismiss="modal" aria-label="Close"></button>
                                <div class="avatar-sm mb-4 mx-auto">
                                    <div class="avatar-title bg-primary text-primary bg-opacity-10 font-size-20 rounded-3">
                                        <i class="mdi mdi-trash-can-outline"></i>
                                    </div>
                                </div>
                                <p class="text-muted font-size-16 mb-4">Are you sure you want to permanently erase the job.</p>
                                
                                <div class="hstack gap-2 justify-content-center mb-0">
                                    <button type="button" class="btn btn-danger">Delete Now</button>
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <!-- end main content-->
            <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script>
   
    function classLists(ele) {
        $.ajax({
            type: "POST",
            url: "<?=base_url('Common/getClassDescbyCode')?>",
            data: {class_code:ele.value},
            dataType: "Json",
            success: function(resultData){
                if(resultData.length>0){
                    $('#class_desc_in').val(resultData[0]['IC_DESC']);
                }else{
                    $('#class_desc_in').val('');
                }
            }
        });
    }

    function catList(ele) {
        $.ajax({
            type: "POST",
            url: "<?=base_url('Common/getCatDescbyCode')?>",
            data: {cat_code:ele.value},
            dataType: "Json",
            success: function(resultData){
                if(resultData.length>0){
                    $('#cat_desc_in').val(resultData[0]['ICAT_DESC']);
                }else{
                    $('#cat_desc_in').val('');
                }
            }
        });
    }

</script>
        